#include <stdio.h>
#include <stdlib.h>
#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <SDL2/SDL_ttf.h>
int pawn_moves(int kill,int w,int l,int y,int x,int chess_board[8][8]);
int horse_moves(int w,int l,int y,int x,int chess_board[8][8],int kill);
int bishop_moves(int w,int l,int y,int x,int chess_board[8][8],int kill);
int rook_moves(int w,int l,int y,int x,int chess_board[8][8],int kill);
int queen_moves(int w,int l,int y,int x,int chess_board[8][8],int kill);
int check(int chess_board[8][8],int w,int l,int y1,int x1,int kill,int pr,int pr2,int pr3,int pr4,int pr5,int pr6,int pr7,int pr8,int prb,int prb2,int prb3,int prb4,int prb5,int prb6,int prb7,int prb8);
int checkmate(int chess_board[8][8],int y,int x,int kill,int pr,int pr2,int pr3,int pr4,int pr5,int pr6,int pr7,int pr8,int prb,int prb2,int prb3,int prb4,int prb5,int prb6,int prb7,int prb8);
int draw(int chess_board[8][8]);
int stalemate(int chess_board[8][8],int y,int x,int kill,int pr,int pr2,int pr3,int pr4,int pr5,int pr6,int pr7,int pr8,int prb,int prb2,int prb3,int prb4,int prb5,int prb6,int prb7,int prb8);
int promotion (int flag,int chees_board[8][8],int x,int y);
int killed(int w,int l,int y,int x,int chess_board[8][8]);
SDL_Rect remove_comp(int num,SDL_Rect pp);
int main(int argc, char* argv[]){
    int turn=0,cc=0,oo,ff,zz=1,arrpiece[1000]={0},arrx[1000]={0},arry[1000]={0},arrkill[1000]={0},arrpr[16][1000],m=1,x=1,y=1,xx=1,yy=1,a=1,c,d,checkmate1,stalemate1,draw1;
    int k1cc=-1,k2cc=-1,kb1cc=-1,kb2cc=-1,pr=0,pr2=0,pr3=0,pr4=0,pr5=0,pr6=0,pr7=0,pr8=0,prb=0,prb2=0,prb3=0,prb4=0,prb5=0,prb6=0,prb7=0,prb8=0,chess_board[8][8]={0},h=0,i,z=0,flag,kill,t=0,castk=0,castr1=0,castr2=0,castrb1=0,castrb2=0,castkb=0;
    int checkmate2=0,checkmate3=0;
    for(int i=0;i<8;i++){
        chess_board[0][i]=(i+1)*-1;
        chess_board[1][i]=(i+11)*-1;
        chess_board[6][i]=(i+61);
        chess_board[7][i]=(i+71);}
    SDL_Rect pp;pp.x=0;pp.y=0;pp.h=100;pp.w=100;
    SDL_Init(SDL_INIT_EVERYTHING);
    IMG_Init(IMG_INIT_JPG|IMG_INIT_PNG);
    SDL_Window *window = SDL_CreateWindow("Chess Game", SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, 1600, 800, SDL_WINDOW_OPENGL);
    SDL_Renderer *render = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED );
    SDL_Surface *rook=IMG_Load("rook.png"),*rook2=IMG_Load("rook.png");
    SDL_Texture *rook_texture= SDL_CreateTextureFromSurface(render,rook),*rook2_texture=SDL_CreateTextureFromSurface(render,rook2);
    SDL_FreeSurface(rook);SDL_FreeSurface(rook2);
    SDL_Rect rook_d,rook2_d;
    rook_d.x=0;rook_d.y=0;rook_d.h=100;rook_d.w=100;
    rook2_d.x=700;rook2_d.y=0;rook2_d.h=100;rook2_d.w=100;
    SDL_Surface *rookpr=IMG_Load("rook.png"),*rookpr2=IMG_Load("rook.png"),*rookpr3=IMG_Load("rook.png"),*rookpr4=IMG_Load("rook.png"),*rookpr5=IMG_Load("rook.png"),*rookpr6=IMG_Load("rook.png"),*rookpr7=IMG_Load("rook.png"),*rookpr8=IMG_Load("rook.png");
    SDL_Texture *rookpr_texture= SDL_CreateTextureFromSurface(render,rookpr),*rookpr2_texture= SDL_CreateTextureFromSurface(render,rookpr2),*rookpr3_texture= SDL_CreateTextureFromSurface(render,rookpr3),*rookpr4_texture= SDL_CreateTextureFromSurface(render,rookpr4),*rookpr5_texture= SDL_CreateTextureFromSurface(render,rookpr5),*rookpr6_texture= SDL_CreateTextureFromSurface(render,rookpr6),*rookpr7_texture= SDL_CreateTextureFromSurface(render,rookpr7),*rookpr8_texture= SDL_CreateTextureFromSurface(render,rookpr8);
    SDL_FreeSurface(rookpr);SDL_FreeSurface(rookpr2);SDL_FreeSurface(rookpr3);SDL_FreeSurface(rookpr4);SDL_FreeSurface(rookpr5);SDL_FreeSurface(rookpr6);SDL_FreeSurface(rookpr7);SDL_FreeSurface(rookpr8);
    SDL_Rect rookpr_d,rookpr2_d,rookpr3_d,rookpr4_d,rookpr5_d,rookpr6_d,rookpr7_d,rookpr8_d;
    SDL_Surface *rookb= IMG_Load("rookb.png"),*rookb2= IMG_Load("rookb.png");
    SDL_Texture *rookb_texture = SDL_CreateTextureFromSurface(render,rookb),*rookb2_texture = SDL_CreateTextureFromSurface(render,rookb2);
    SDL_FreeSurface(rookb),SDL_FreeSurface(rookb2);
    SDL_Rect rookb_d,rookb2_d;
    rookb_d.x=0;rookb_d.y=700;rookb_d.h=100;rookb_d.w=100;
    rookb2_d.x=700;rookb2_d.y=700;rookb2_d.h=100;rookb2_d.w=100;
    SDL_Surface *rookprb=IMG_Load("rookb.png"),*rookprb2=IMG_Load("rookb.png"),*rookprb3=IMG_Load("rookb.png"),*rookprb4=IMG_Load("rookb.png"),*rookprb5=IMG_Load("rookb.png"),*rookprb6=IMG_Load("rookb.png"),*rookprb7=IMG_Load("rookb.png"),*rookprb8=IMG_Load("rookb.png");
    SDL_Texture *rookprb_texture= SDL_CreateTextureFromSurface(render,rookprb),*rookprb2_texture= SDL_CreateTextureFromSurface(render,rookprb2),*rookprb3_texture= SDL_CreateTextureFromSurface(render,rookprb3),*rookprb4_texture= SDL_CreateTextureFromSurface(render,rookprb4),*rookprb5_texture= SDL_CreateTextureFromSurface(render,rookprb5),*rookprb6_texture= SDL_CreateTextureFromSurface(render,rookprb6),*rookprb7_texture= SDL_CreateTextureFromSurface(render,rookprb7),*rookprb8_texture= SDL_CreateTextureFromSurface(render,rookprb8);
    SDL_FreeSurface(rookprb);SDL_FreeSurface(rookprb2);SDL_FreeSurface(rookprb3);SDL_FreeSurface(rookprb4);SDL_FreeSurface(rookprb5);SDL_FreeSurface(rookprb6);SDL_FreeSurface(rookprb7);SDL_FreeSurface(rookprb8);
    SDL_Rect rookprb_d,rookprb2_d,rookprb3_d,rookprb4_d,rookprb5_d,rookprb6_d,rookprb7_d,rookprb8_d;
    SDL_Surface *pawn= IMG_Load("pawn.png"),*pawn2= IMG_Load("pawn.png"),*pawn3= IMG_Load("pawn.png"),*pawn4= IMG_Load("pawn.png"),*pawn5= IMG_Load("pawn.png"),*pawn6= IMG_Load("pawn.png"),*pawn7= IMG_Load("pawn.png"),*pawn8= IMG_Load("pawn.png");
    SDL_Texture *pawn_texture = SDL_CreateTextureFromSurface(render,pawn),*pawn2_texture = SDL_CreateTextureFromSurface(render,pawn2),*pawn3_texture = SDL_CreateTextureFromSurface(render,pawn3),*pawn4_texture = SDL_CreateTextureFromSurface(render,pawn4),*pawn5_texture = SDL_CreateTextureFromSurface(render,pawn5),*pawn6_texture = SDL_CreateTextureFromSurface(render,pawn6),*pawn7_texture = SDL_CreateTextureFromSurface(render,pawn7),*pawn8_texture = SDL_CreateTextureFromSurface(render,pawn8);
    SDL_FreeSurface(pawn),SDL_FreeSurface(pawn2),SDL_FreeSurface(pawn3),SDL_FreeSurface(pawn4),SDL_FreeSurface(pawn5),SDL_FreeSurface(pawn6),SDL_FreeSurface(pawn7),SDL_FreeSurface(pawn8);
    SDL_Rect pawn_d,pawn2_d,pawn3_d,pawn4_d,pawn5_d,pawn6_d,pawn7_d,pawn8_d;
    pawn_d.x=0; pawn_d.y=100;pawn_d.h=100;pawn_d.w=100;
    pawn2_d.x=100; pawn2_d.y=100;pawn2_d.h=100;pawn2_d.w=100;
    pawn3_d.x=200; pawn3_d.y=100;pawn3_d.h=100;pawn3_d.w=100;
    pawn4_d.x=300; pawn4_d.y=100;pawn4_d.h=100;pawn4_d.w=100;
    pawn5_d.x=400; pawn5_d.y=100;pawn5_d.h=100;pawn5_d.w=100;
    pawn6_d.x=500; pawn6_d.y=100;pawn6_d.h=100;pawn6_d.w=100;
    pawn7_d.x=600; pawn7_d.y=100;pawn7_d.h=100;pawn7_d.w=100;
    pawn8_d.x=700; pawn8_d.y=100;pawn8_d.h=100;pawn8_d.w=100;
    SDL_Surface *pawnb= IMG_Load("pawnb.png"),*pawnb2= IMG_Load("pawnb.png"),*pawnb3= IMG_Load("pawnb.png"),*pawnb4= IMG_Load("pawnb.png"),*pawnb5= IMG_Load("pawnb.png"),*pawnb6= IMG_Load("pawnb.png"),*pawnb7= IMG_Load("pawnb.png"),*pawnb8= IMG_Load("pawnb.png");
    SDL_Texture *pawnb_texture = SDL_CreateTextureFromSurface(render,pawnb),*pawnb2_texture = SDL_CreateTextureFromSurface(render,pawnb2),*pawnb3_texture = SDL_CreateTextureFromSurface(render,pawnb3),*pawnb4_texture = SDL_CreateTextureFromSurface(render,pawnb4),*pawnb5_texture = SDL_CreateTextureFromSurface(render,pawnb5),*pawnb6_texture = SDL_CreateTextureFromSurface(render,pawnb6),*pawnb7_texture = SDL_CreateTextureFromSurface(render,pawnb7),*pawnb8_texture = SDL_CreateTextureFromSurface(render,pawnb8);
    SDL_FreeSurface(pawnb),SDL_FreeSurface(pawnb2),SDL_FreeSurface(pawnb3),SDL_FreeSurface(pawnb4),SDL_FreeSurface(pawnb5),SDL_FreeSurface(pawnb6),SDL_FreeSurface(pawnb7),SDL_FreeSurface(pawnb8);
    SDL_Rect pawnb_d,pawnb2_d,pawnb3_d,pawnb4_d,pawnb5_d,pawnb6_d,pawnb7_d,pawnb8_d;
    pawnb_d.x=0; pawnb_d.y=600;pawnb_d.h=100;pawnb_d.w=100;
    pawnb2_d.x=100; pawnb2_d.y=600;pawnb2_d.h=100;pawnb2_d.w=100;
    pawnb3_d.x=200; pawnb3_d.y=600;pawnb3_d.h=100;pawnb3_d.w=100;
    pawnb4_d.x=300; pawnb4_d.y=600;pawnb4_d.h=100;pawnb4_d.w=100;
    pawnb5_d.x=400; pawnb5_d.y=600;pawnb5_d.h=100;pawnb5_d.w=100;
    pawnb6_d.x=500; pawnb6_d.y=600;pawnb6_d.h=100;pawnb6_d.w=100;
    pawnb7_d.x=600; pawnb7_d.y=600;pawnb7_d.h=100;pawnb7_d.w=100;
    pawnb8_d.x=700; pawnb8_d.y=600;pawnb8_d.h=100;pawnb8_d.w=100;
    SDL_Surface *eleph= IMG_Load("eleph.png"),*eleph2= IMG_Load("eleph.png");
    SDL_Texture *eleph_texture = SDL_CreateTextureFromSurface(render,eleph),*eleph2_texture = SDL_CreateTextureFromSurface(render,eleph2);
    SDL_FreeSurface(eleph),SDL_FreeSurface(eleph2);
    SDL_Rect eleph_d,eleph2_d;
    eleph_d.x=200;eleph_d.y=0;eleph_d.h=100;eleph_d.w=100;
    eleph2_d.x=500;eleph2_d.y=0;eleph2_d.h=100;eleph2_d.w=100;
    SDL_Surface *elephpr= IMG_Load("eleph.png"),*elephpr2= IMG_Load("eleph.png"),*elephpr3= IMG_Load("eleph.png"),*elephpr4= IMG_Load("eleph.png"),*elephpr5= IMG_Load("eleph.png"),*elephpr6= IMG_Load("eleph.png"),*elephpr7= IMG_Load("eleph.png"),*elephpr8= IMG_Load("eleph.png");
    SDL_Texture *elephpr_texture = SDL_CreateTextureFromSurface(render,elephpr),*elephpr2_texture = SDL_CreateTextureFromSurface(render,elephpr2),*elephpr3_texture = SDL_CreateTextureFromSurface(render,elephpr3),*elephpr4_texture = SDL_CreateTextureFromSurface(render,elephpr4),*elephpr5_texture = SDL_CreateTextureFromSurface(render,elephpr5),*elephpr6_texture = SDL_CreateTextureFromSurface(render,elephpr6),*elephpr7_texture = SDL_CreateTextureFromSurface(render,elephpr7),*elephpr8_texture = SDL_CreateTextureFromSurface(render,elephpr8);
    SDL_FreeSurface(elephpr);SDL_FreeSurface(elephpr2);SDL_FreeSurface(elephpr3);SDL_FreeSurface(elephpr4);SDL_FreeSurface(elephpr5);SDL_FreeSurface(elephpr6);SDL_FreeSurface(elephpr7);SDL_FreeSurface(elephpr8);
    SDL_Rect elephpr_d,elephpr2_d,elephpr3_d,elephpr4_d,elephpr5_d,elephpr6_d,elephpr7_d,elephpr8_d;
    SDL_Surface *elephb= IMG_Load("elephb.png"),*elephb2= IMG_Load("elephb.png");
    SDL_Texture *elephb_texture = SDL_CreateTextureFromSurface(render,elephb),*elephb2_texture = SDL_CreateTextureFromSurface(render,elephb2);
    SDL_FreeSurface(elephb),SDL_FreeSurface(elephb2);
    SDL_Rect elephb_d,elephb2_d;
    elephb_d.x=200;elephb_d.y=700;elephb_d.h=100;elephb_d.w=100;
    elephb2_d.x=500;elephb2_d.y=700;elephb2_d.h=100;elephb2_d.w=100;
    SDL_Surface *elephprb= IMG_Load("elephb.png"),*elephprb2= IMG_Load("elephb.png"),*elephprb3= IMG_Load("elephb.png"),*elephprb4= IMG_Load("elephb.png"),*elephprb5= IMG_Load("elephb.png"),*elephprb6= IMG_Load("elephb.png"),*elephprb7= IMG_Load("elephb.png"),*elephprb8= IMG_Load("elephb.png");
    SDL_Texture *elephprb_texture = SDL_CreateTextureFromSurface(render,elephprb),*elephprb2_texture = SDL_CreateTextureFromSurface(render,elephprb2),*elephprb3_texture = SDL_CreateTextureFromSurface(render,elephprb3),*elephprb4_texture = SDL_CreateTextureFromSurface(render,elephprb4),*elephprb5_texture = SDL_CreateTextureFromSurface(render,elephprb5),*elephprb6_texture = SDL_CreateTextureFromSurface(render,elephprb6),*elephprb7_texture = SDL_CreateTextureFromSurface(render,elephprb7),*elephprb8_texture = SDL_CreateTextureFromSurface(render,elephprb8);
    SDL_FreeSurface(elephprb);SDL_FreeSurface(elephprb2);SDL_FreeSurface(elephprb3);SDL_FreeSurface(elephprb4);SDL_FreeSurface(elephprb5);SDL_FreeSurface(elephprb6);SDL_FreeSurface(elephprb7);SDL_FreeSurface(elephprb8);
    SDL_Rect elephprb_d,elephprb2_d,elephprb3_d,elephprb4_d,elephprb5_d,elephprb6_d,elephprb7_d,elephprb8_d;
    SDL_Surface *knight= IMG_Load("knight.png"),*knight2= IMG_Load("knight.png");
    SDL_Texture *knight_texture = SDL_CreateTextureFromSurface(render,knight),*knight2_texture = SDL_CreateTextureFromSurface(render,knight2);
    SDL_FreeSurface(knight),SDL_FreeSurface(knight2);
    SDL_Rect knight_d,knight2_d;
    knight_d.x=100;knight_d.y=0;knight_d.h=100;knight_d.w=100;
    knight2_d.x=600;knight2_d.y=0;knight2_d.h=100;knight2_d.w=100;
    SDL_Surface *knightpr= IMG_Load("knight.png"),*knightpr2= IMG_Load("knight.png"),*knightpr3= IMG_Load("knight.png"),*knightpr4= IMG_Load("knight.png"),*knightpr5= IMG_Load("knight.png"),*knightpr6= IMG_Load("knight.png"),*knightpr7= IMG_Load("knight.png"),*knightpr8= IMG_Load("knight.png");
    SDL_Texture *knightpr_texture = SDL_CreateTextureFromSurface(render,knightpr),*knightpr2_texture = SDL_CreateTextureFromSurface(render,knightpr2),*knightpr3_texture = SDL_CreateTextureFromSurface(render,knightpr3),*knightpr4_texture = SDL_CreateTextureFromSurface(render,knightpr4),*knightpr5_texture = SDL_CreateTextureFromSurface(render,knightpr5),*knightpr6_texture = SDL_CreateTextureFromSurface(render,knightpr6),*knightpr7_texture = SDL_CreateTextureFromSurface(render,knightpr7),*knightpr8_texture = SDL_CreateTextureFromSurface(render,knightpr8);
    SDL_FreeSurface(knightpr);SDL_FreeSurface(knightpr2);SDL_FreeSurface(knightpr3);SDL_FreeSurface(knightpr4);SDL_FreeSurface(knightpr5);SDL_FreeSurface(knightpr6);SDL_FreeSurface(knightpr7);SDL_FreeSurface(knightpr8);
    SDL_Rect knightpr_d,knightpr2_d,knightpr3_d,knightpr4_d,knightpr5_d,knightpr6_d,knightpr7_d,knightpr8_d;
    SDL_Surface *knightb= IMG_Load("knightb.png"),*knightb2= IMG_Load("knightb.png");
    SDL_Texture *knightb_texture = SDL_CreateTextureFromSurface(render,knightb),*knightb2_texture = SDL_CreateTextureFromSurface(render,knightb2);
    SDL_FreeSurface(knightb),SDL_FreeSurface(knightb2);
    SDL_Rect knightb_d,knightb2_d;
    knightb_d.x=100;knightb_d.y=700;knightb_d.h=100;knightb_d.w=100;
    knightb2_d.x=600;knightb2_d.y=700;knightb2_d.h=100;knightb2_d.w=100;
    SDL_Surface *knightprb= IMG_Load("knightb.png"),*knightprb2= IMG_Load("knightb.png"),*knightprb3= IMG_Load("knightb.png"),*knightprb4= IMG_Load("knightb.png"),*knightprb5= IMG_Load("knightb.png"),*knightprb6= IMG_Load("knightb.png"),*knightprb7= IMG_Load("knightb.png"),*knightprb8= IMG_Load("knightb.png");
    SDL_Texture *knightprb_texture = SDL_CreateTextureFromSurface(render,knightprb),*knightprb2_texture = SDL_CreateTextureFromSurface(render,knightprb2),*knightprb3_texture = SDL_CreateTextureFromSurface(render,knightprb3),*knightprb4_texture = SDL_CreateTextureFromSurface(render,knightprb4),*knightprb5_texture = SDL_CreateTextureFromSurface(render,knightprb5),*knightprb6_texture = SDL_CreateTextureFromSurface(render,knightprb6),*knightprb7_texture = SDL_CreateTextureFromSurface(render,knightprb7),*knightprb8_texture = SDL_CreateTextureFromSurface(render,knightprb8);
    SDL_FreeSurface(knightprb);SDL_FreeSurface(knightprb2);SDL_FreeSurface(knightprb3);SDL_FreeSurface(knightprb4);SDL_FreeSurface(knightprb5);SDL_FreeSurface(knightprb6);SDL_FreeSurface(knightprb7);SDL_FreeSurface(knightprb8);
    SDL_Rect knightprb_d,knightprb2_d,knightprb3_d,knightprb4_d,knightprb5_d,knightprb6_d,knightprb7_d,knightprb8_d;
    SDL_Surface *queen= IMG_Load("queen.png");
    SDL_Texture *queen_texture = SDL_CreateTextureFromSurface(render,queen);
    SDL_FreeSurface(queen);
    SDL_Rect queen_d;
    queen_d.x=400;queen_d.y=0;queen_d.h=100;queen_d.w=100;
    SDL_Surface *queenpr= IMG_Load("queen.png"),*queenpr2= IMG_Load("queen.png"),*queenpr3= IMG_Load("queen.png"),*queenpr4= IMG_Load("queen.png"),*queenpr5= IMG_Load("queen.png"),*queenpr6= IMG_Load("queen.png"),*queenpr7= IMG_Load("queen.png"),*queenpr8= IMG_Load("queen.png");
    SDL_Texture *queenpr_texture = SDL_CreateTextureFromSurface(render,queenpr),*queenpr2_texture = SDL_CreateTextureFromSurface(render,queenpr2),*queenpr3_texture = SDL_CreateTextureFromSurface(render,queenpr3),*queenpr4_texture = SDL_CreateTextureFromSurface(render,queenpr4),*queenpr5_texture = SDL_CreateTextureFromSurface(render,queenpr5),*queenpr6_texture = SDL_CreateTextureFromSurface(render,queenpr6),*queenpr7_texture = SDL_CreateTextureFromSurface(render,queenpr7),*queenpr8_texture = SDL_CreateTextureFromSurface(render,queenpr8);
    SDL_FreeSurface(queenpr);SDL_FreeSurface(queenpr2);SDL_FreeSurface(queenpr3);SDL_FreeSurface(queenpr4);SDL_FreeSurface(queenpr5);SDL_FreeSurface(queenpr6);SDL_FreeSurface(queenpr7);SDL_FreeSurface(queenpr8);
    SDL_Rect queenpr_d,queenpr2_d,queenpr3_d,queenpr4_d,queenpr5_d,queenpr6_d,queenpr7_d,queenpr8_d;
    SDL_Surface *queenb= IMG_Load("queenb.png");
    SDL_Texture *queenb_texture = SDL_CreateTextureFromSurface(render,queenb);
    SDL_FreeSurface(queenb);
    SDL_Rect queenb_d;
    queenb_d.x=400;queenb_d.y=700;queenb_d.h=100;queenb_d.w=100;
    SDL_Surface *queenprb= IMG_Load("queenb.png"),*queenprb2= IMG_Load("queenb.png"),*queenprb3= IMG_Load("queenb.png"),*queenprb4= IMG_Load("queenb.png"),*queenprb5= IMG_Load("queenb.png"),*queenprb6= IMG_Load("queenb.png"),*queenprb7= IMG_Load("queenb.png"),*queenprb8= IMG_Load("queenb.png");
    SDL_Texture *queenprb_texture = SDL_CreateTextureFromSurface(render,queenprb),*queenprb2_texture = SDL_CreateTextureFromSurface(render,queenprb2),*queenprb3_texture = SDL_CreateTextureFromSurface(render,queenprb3),*queenprb4_texture = SDL_CreateTextureFromSurface(render,queenprb4),*queenprb5_texture = SDL_CreateTextureFromSurface(render,queenprb5),*queenprb6_texture = SDL_CreateTextureFromSurface(render,queenprb6),*queenprb7_texture = SDL_CreateTextureFromSurface(render,queenprb7),*queenprb8_texture = SDL_CreateTextureFromSurface(render,queenprb8);
    SDL_FreeSurface(queenprb);SDL_FreeSurface(queenprb2);SDL_FreeSurface(queenprb3);SDL_FreeSurface(queenprb4);SDL_FreeSurface(queenprb5);SDL_FreeSurface(queenprb6);SDL_FreeSurface(queenprb7);SDL_FreeSurface(queenprb8);
    SDL_Rect queenprb_d,queenprb2_d,queenprb3_d,queenprb4_d,queenprb5_d,queenprb6_d,queenprb7_d,queenprb8_d;
    SDL_Surface *king= IMG_Load("king.png");
    SDL_Texture *king_texture = SDL_CreateTextureFromSurface(render,king);
    SDL_FreeSurface(king);
    SDL_Rect king_d;
    king_d.x=300;king_d.y=0;king_d.h=100;king_d.w=100;
    SDL_Surface *kingb= IMG_Load("kingb.png");
    SDL_Texture *kingb_texture = SDL_CreateTextureFromSurface(render,kingb);
    SDL_FreeSurface(kingb);
    SDL_Rect kingb_d;
    kingb_d.x=300;kingb_d.y=700;kingb_d.h=100;kingb_d.w=100;
    SDL_Rect rec3;
    rec3.x=1200;rec3.y=300;rec3.w=100;rec3.h=100;
    SDL_Surface *save= IMG_Load("save.jpg");
    SDL_Texture *save_texture = SDL_CreateTextureFromSurface(render,save);
    SDL_FreeSurface(save);
    SDL_Rect rec4;
    rec4.x=1300;rec4.y=300;rec4.w=100;rec4.h=100;
    SDL_Surface *load= IMG_Load("load.png");
    SDL_Texture *load_texture = SDL_CreateTextureFromSurface(render,load);
    SDL_FreeSurface(load);
    SDL_Rect rec5;
    rec5.x=1400;rec5.y=300;rec5.w=100;rec5.h=100;
    SDL_Surface *undo= IMG_Load("undo.jpg");
    SDL_Texture *undo_texture = SDL_CreateTextureFromSurface(render,undo);
    SDL_FreeSurface(undo);
    SDL_Rect rec6;
    rec6.x=1500;rec6.y=300;rec6.w=100;rec6.h=100;
    SDL_Surface *redo= IMG_Load("redo.jpg");
    SDL_Texture *redo_texture = SDL_CreateTextureFromSurface(render,redo);
    SDL_FreeSurface(redo);
    TTF_Init();
    TTF_Font *font=TTF_OpenFont("emmasophia.ttf",17);
    SDL_Color color;
    color.r=0;color.b=0;color.g=0;color.a=255;
    SDL_Surface *text=TTF_RenderText_Solid(font,"white turn",color),*text2=TTF_RenderText_Solid(font,"black turn",color),*text3=TTF_RenderText_Solid(font,"check",color),*text4=TTF_RenderText_Solid(font,"draw",color),*text5=TTF_RenderText_Solid(font,"white win",color),*text6=TTF_RenderText_Solid(font,"black win",color);
    SDL_Texture *text_texture =SDL_CreateTextureFromSurface(render,text),*text2_texture =SDL_CreateTextureFromSurface(render,text2),*text3_texture =SDL_CreateTextureFromSurface(render,text3),*text4_texture =SDL_CreateTextureFromSurface(render,text4),*text5_texture =SDL_CreateTextureFromSurface(render,text5),*text6_texture =SDL_CreateTextureFromSurface(render,text6);
    SDL_FreeSurface(text);SDL_FreeSurface(text2);SDL_FreeSurface(text3);SDL_FreeSurface(text4);SDL_FreeSurface(text5);SDL_FreeSurface(text6);
    SDL_Rect textrect,textrect2,textrect3,textrect4,textrect5,textrect6;
    textrect.x=850;textrect.y=400;
    textrect2.x=850;textrect2.y=300;textrect3.x=850;textrect3.y=300;textrect4.x=850;textrect4.y=300;textrect5.x=850;textrect5.y=300;textrect6.x=850;textrect6.y=300;
    SDL_QueryTexture(text_texture,NULL,NULL,&textrect.w,&textrect.h);
    SDL_QueryTexture(text2_texture,NULL,NULL,&textrect2.w,&textrect2.h);
    SDL_QueryTexture(text3_texture,NULL,NULL,&textrect3.w,&textrect3.h);
    SDL_QueryTexture(text4_texture,NULL,NULL,&textrect4.w,&textrect4.h);
    SDL_QueryTexture(text5_texture,NULL,NULL,&textrect5.w,&textrect5.h);
    SDL_QueryTexture(text6_texture,NULL,NULL,&textrect6.w,&textrect6.h);
    SDL_Surface *text7=TTF_RenderText_Solid(font,"wrong move",color);
    SDL_Texture *text7_texture =SDL_CreateTextureFromSurface(render,text7);
    SDL_FreeSurface(text7);
    SDL_Rect textrect7;textrect7.x=850;textrect7.y=300;
    SDL_QueryTexture(text7_texture,NULL,NULL,&textrect7.w,&textrect7.h);
    FILE * finout;
    SDL_Event event;
    while(m){
        while(SDL_PollEvent(&event)){
            if(event.type==SDL_QUIT)
                m=0;
            else if(event.type==SDL_MOUSEBUTTONDOWN){
                    x=event.button.x;
                    y=event.button.y;
                    if(a==1){c=(x/100);d=(y/100);a=0;}
                    else if(a==0){
                        x=(x/100);y=(y/100);
                        if(((checkmate1==1&&stalemate1==0)||(draw1==1)||(stalemate1=0&&checkmate1==0))&&(c<8&&d<8)){a=1;
                            textrect3.x=850;textrect3.y=300;textrect4.x=850;textrect4.y=300;textrect5.x=850;textrect5.y=300;textrect6.x=850;textrect6.y=300;
                            if(checkmate1==1&&stalemate1==1){textrect3.x=1050;textrect3.y=400;}
                                    else if(draw1==1){textrect.x=850;textrect.y=300;textrect2.x=850;textrect2.y=300;textrect4.x=850;textrect4.y=400;}
                                    else if(checkmate1==0 && stalemate1==0){textrect.x=850;textrect.y=300;textrect2.x=850;textrect2.y=300;textrect4.x=850;textrect4.y=400;}
                                    else if(checkmate1==1 && stalemate1==0 && h<0){textrect.x=850;textrect.y=300;textrect2.x=850;textrect2.y=300;textrect6.x=850;textrect6.y=400;}
                                    else if(checkmate1==1 && stalemate1==0 && h>0){textrect.x=850;textrect.y=300;textrect2.x=850;textrect2.y=300;textrect5.x=850;textrect5.y=400;}}
                       else if(x==c&&y==d&&c==12&&d==3){
                            finout=fopen("ebbram.txt","w");
                             for(int i=0;i<8;i++){
                                for(int j=0;j<8;j++){
                            fprintf(finout,"chess_board[%d][%d]=%d\n",i,j,chess_board[i][j]);}}
                            fprintf(finout,"turn=%d\n",turn);
                            fprintf(finout,"pr=%d\npr2=%d\npr3=%d\npr4=%d\npr5=%d\npr6=%d\npr7=%d\npr8=%d\nprb=%d\nprb2=%d\nprb3=%d\nprb4=%d\nprb5=%d\nprb6=%d\nprb7=%d\nprb8=%d\n",pr,pr2,pr3,pr4,pr5,pr6,pr7,pr8,prb,prb2,prb3,prb4,prb5,prb6,prb7,prb8);a=1;}
                        else if((x==c&&y==d&&c==13&&d==3) || (x==c&&y==d&&c==14&&d==3) || (x==c&&y==d&&c==15&&d==3)){
                            if(x==c&&y==d&&c==13&&d==3&&arrpiece[0]==0){
                            finout=fopen("ebbram.txt","r");
                            fscanf(finout,"chess_board[0][0]=%d\nchess_board[0][1]=%d\nchess_board[0][2]=%d\nchess_board[0][3]=%d\nchess_board[0][4]=%d\nchess_board[0][5]=%d\nchess_board[0][6]=%d\nchess_board[0][7]=%d\nchess_board[1][0]=%d\nchess_board[1][1]=%d\nchess_board[1][2]=%d\nchess_board[1][3]=%d\nchess_board[1][4]=%d\nchess_board[1][5]=%d\nchess_board[1][6]=%d\nchess_board[1][7]=%d\nchess_board[2][0]=%d\nchess_board[2][1]=%d\nchess_board[2][2]=%d\nchess_board[2][3]=%d\nchess_board[2][4]=%d\nchess_board[2][5]=%d\nchess_board[2][6]=%d\nchess_board[2][7]=%d\nchess_board[3][0]=%d\nchess_board[3][1]=%d\nchess_board[3][2]=%d\nchess_board[3][3]=%d\nchess_board[3][4]=%d\nchess_board[3][5]=%d\nchess_board[3][6]=%d\nchess_board[3][7]=%d\nchess_board[4][0]=%d\nchess_board[4][1]=%d\nchess_board[4][2]=%d\nchess_board[4][3]=%d\nchess_board[4][4]=%d\nchess_board[4][5]=%d\nchess_board[4][6]=%d\nchess_board[4][7]=%d\nchess_board[5][0]=%d\nchess_board[5][1]=%d\nchess_board[5][2]=%d\nchess_board[5][3]=%d\nchess_board[5][4]=%d\nchess_board[5][5]=%d\nchess_board[5][6]=%d\nchess_board[5][7]=%d\nchess_board[6][0]=%d\nchess_board[6][1]=%d\nchess_board[6][2]=%d\nchess_board[6][3]=%d\nchess_board[6][4]=%d\nchess_board[6][5]=%d\nchess_board[6][6]=%d\nchess_board[6][7]=%d\nchess_board[7][0]=%d\nchess_board[7][1]=%d\nchess_board[7][2]=%d\nchess_board[7][3]=%d\nchess_board[7][4]=%d\nchess_board[7][5]=%d\nchess_board[7][6]=%d\nchess_board[7][7]=%d\n",&chess_board[0][0],&chess_board[0][1],&chess_board[0][2],&chess_board[0][3],&chess_board[0][4],&chess_board[0][5],&chess_board[0][6],&chess_board[0][7],&chess_board[1][0],&chess_board[1][1],&chess_board[1][2],&chess_board[1][3],&chess_board[1][4],&chess_board[1][5],&chess_board[1][6],&chess_board[1][7],&chess_board[2][0],&chess_board[2][1],&chess_board[2][2],&chess_board[2][3],&chess_board[2][4],&chess_board[2][5],&chess_board[2][6],&chess_board[2][7],&chess_board[3][0],&chess_board[3][1],&chess_board[3][2],&chess_board[3][3],&chess_board[3][4],&chess_board[3][5],&chess_board[3][6],&chess_board[3][7],&chess_board[4][0],&chess_board[4][1],&chess_board[4][2],&chess_board[4][3],&chess_board[4][4],&chess_board[4][5],&chess_board[4][6],&chess_board[4][7],&chess_board[5][0],&chess_board[5][1],&chess_board[5][2],&chess_board[5][3],&chess_board[5][4],&chess_board[5][5],&chess_board[5][6],&chess_board[5][7],&chess_board[6][0],&chess_board[6][1],&chess_board[6][2],&chess_board[6][3],&chess_board[6][4],&chess_board[6][5],&chess_board[6][6],&chess_board[6][7],&chess_board[7][0],&chess_board[7][1],&chess_board[7][2],&chess_board[7][3],&chess_board[7][4],&chess_board[7][5],&chess_board[7][6],&chess_board[7][7]);
                            fscanf(finout,"turn=%d\npr=%d\npr2=%d\npr3=%d\npr4=%d\npr5=%d\npr6=%d\npr7=%d\npr8=%d\nprb=%d\nprb2=%d\nprb3=%d\nprb4=%d\nprb5=%d\nprb6=%d\nprb7=%d\nprb8=%d\n",&turn,&pr,&pr2,&pr3,&pr4,&pr5,&pr6,&pr7,&pr8,&prb,&prb2,&prb3,&prb4,&prb5,&prb6,&prb7,&prb8);
                            if(turn==1){textrect2.x=850;textrect2.y=400;textrect.x=850;textrect.y=300;}
                            else if(turn==0){textrect.x=850;textrect.y=400;textrect2.x=850;textrect2.y=300;}
                            flag=1;}
                            else if(x==c&&y==d&&c==14&&d==3&&cc!=0){
                                    if(k1cc==cc-1){chess_board[0][0]=chess_board[0][2];chess_board[0][2]=0;}
                                   if(k2cc==cc-1){chess_board[0][7]=chess_board[0][4];chess_board[0][4]=0;}
                                    if(kb1cc==cc-1){chess_board[7][0]=chess_board[7][2];chess_board[7][2]=0;}
                                   if(kb2cc==cc-1){chess_board[7][7]=chess_board[7][4];chess_board[7][4]=0;}
                                    for(int iii=0;iii<8;iii++){
                                        for(int jjj=0;jjj<8;jjj++){
                                            if(chess_board[iii][jjj]==arrpiece[cc-1]){ff=jjj;oo=iii;}}}
                                            if(arrpiece[cc-1]!=0){
                                                chess_board[arry[cc-1]][arrx[cc-1]]=arrpiece[cc-1];
                                                chess_board[oo][ff]=arrkill[cc-1];
                                                arry[cc-1]=oo;arrx[cc-1]=ff;
                                                cc--;zz=0;flag=1;
                                                pr=arrpr[0][cc-1];pr2=arrpr[1][cc-1];pr3=arrpr[2][cc-1];pr4=arrpr[3][cc-1];pr5=arrpr[4][cc-1];pr6=arrpr[5][cc-1];pr7=arrpr[6][cc-1];pr8=arrpr[7][cc-1];prb=arrpr[8][cc-1];prb2=arrpr[9][cc-1];prb3=arrpr[10][cc-1];prb4=arrpr[11][cc-1];prb5=arrpr[12][cc-1];prb6=arrpr[13][cc-1];prb7=arrpr[14][cc-1];prb8=arrpr[15][cc-1];
                                                textrect7.x=850;textrect7.y=300;
                                                if(turn==0){turn=1;textrect2.x=850;textrect2.y=400;textrect.x=850;textrect.y=300;}
                                                else if(turn==1){turn=0;textrect2.x=850;textrect2.y=300;textrect.x=850;textrect.y=400;}
                                                textrect3.x=850;textrect3.y=300;textrect4.x=850;textrect4.y=300;textrect5.x=850;textrect5.y=300;textrect6.x=850;textrect6.y=300;}}
                            else if(x==c&&y==d&&c==15&&d==3){
                                    if(k1cc==cc){chess_board[0][2]=chess_board[0][0];chess_board[0][0]=0;}
                                   if(k2cc==cc){chess_board[0][4]=chess_board[0][7];chess_board[0][7]=0;}
                                    if(kb1cc==cc){chess_board[7][2]=chess_board[7][0];chess_board[7][0]=0;}
                                   if(kb2cc==cc){chess_board[7][4]=chess_board[7][7];chess_board[7][7]=0;}
                                    for(int iii=0;iii<8;iii++){
                                        for(int jjj=0;jjj<8;jjj++){
                                            if(chess_board[iii][jjj]==arrpiece[cc]){ff=jjj;oo=iii;}}}
                                if(arrpiece[cc]!=0&&zz==0){
                                    chess_board[arry[cc]][arrx[cc]]=arrpiece[cc];
                                    chess_board[oo][ff]=0;
                                    pr=arrpr[0][cc];pr2=arrpr[1][cc];pr3=arrpr[2][cc];pr4=arrpr[3][cc];pr5=arrpr[4][cc];pr6=arrpr[5][cc];pr7=arrpr[6][cc];pr8=arrpr[7][cc];prb=arrpr[8][cc];prb2=arrpr[9][cc];prb3=arrpr[10][cc];prb4=arrpr[11][cc];prb5=arrpr[12][cc];prb6=arrpr[13][cc];prb7=arrpr[14][cc];prb8=arrpr[15][cc];
                                    arry[cc]=oo;arrx[cc]=ff;
                                    cc++;zz=0;flag=1;textrect7.x=850;textrect7.y=300;
                                if(turn==0){turn=1;textrect2.x=850;textrect2.y=400;textrect.x=850;textrect.y=300;}
                                else if(turn==1){turn=0;textrect2.x=850;textrect2.y=300;textrect.x=850;textrect.y=400;}
                                textrect3.x=850;textrect3.y=300;textrect4.x=850;textrect4.y=300;textrect5.x=850;textrect5.y=300;textrect6.x=850;textrect6.y=300;}}
                            rook_d=remove_comp(-1,pp);knight_d=remove_comp(-2,pp);eleph_d=remove_comp(-3,pp);king_d=remove_comp(-4,pp);queen_d=remove_comp(-5,pp);eleph2_d=remove_comp(-6,pp);knight2_d=remove_comp(-7,pp);rook2_d=remove_comp(-8,pp);
                            pawn_d=remove_comp(-11,pp);pawn2_d=remove_comp(-12,pp);pawn3_d=remove_comp(-13,pp);pawn4_d=remove_comp(-14,pp);pawn5_d=remove_comp(-15,pp);pawn6_d=remove_comp(-16,pp);pawn7_d=remove_comp(-17,pp);pawn8_d=remove_comp(-18,pp);
                            pawnb_d=remove_comp(61,pp);pawnb2_d=remove_comp(62,pp);pawnb3_d=remove_comp(63,pp);pawnb4_d=remove_comp(64,pp);pawnb5_d=remove_comp(65,pp);pawnb6_d=remove_comp(66,pp);pawnb7_d=remove_comp(67,pp);pawnb8_d=remove_comp(68,pp);
                            rookb_d=remove_comp(71,pp);knightb_d=remove_comp(72,pp);elephb_d=remove_comp(73,pp);kingb_d=remove_comp(74,pp);queenb_d=remove_comp(75,pp);elephb2_d=remove_comp(76,pp);knightb2_d=remove_comp(77,pp);rookb2_d=remove_comp(78,pp);
                            queenpr_d.x=2000;rookpr_d.x=2000;elephpr_d.x=2000;knightpr_d.x=2000;queenpr2_d.x=2000;rookpr2_d.x=2000;elephpr2_d.x=2000;knightpr2_d.x=2000;queenpr3_d.x=2000;rookpr3_d.x=2000;elephpr3_d.x=2000;knightpr3_d.x=2000;queenpr4_d.x=2000;rookpr4_d.x=2000;elephpr4_d.x=2000;knightpr4_d.x=2000;queenpr5_d.x=2000;rookpr5_d.x=2000;elephpr5_d.x=2000;knightpr5_d.x=2000;queenpr6_d.x=2000;rookpr6_d.x=2000;elephpr6_d.x=2000;knightpr6_d.x=2000;queenpr7_d.x=2000;rookpr7_d.x=2000;elephpr7_d.x=2000;knightpr7_d.x=2000;queenpr8_d.x=2000;rookpr8_d.x=2000;elephpr8_d.x=2000;knightpr8_d.x=2000;
                            queenprb_d.x=2000;rookprb_d.x=2000;elephprb_d.x=2000;knightprb_d.x=2000;queenprb2_d.x=2000;rookprb2_d.x=2000;elephprb2_d.x=2000;knightprb2_d.x=2000;queenprb3_d.x=2000;rookprb3_d.x=2000;elephprb3_d.x=2000;knightprb3_d.x=2000;queenprb4_d.x=2000;rookprb4_d.x=2000;elephprb4_d.x=2000;knightprb4_d.x=2000;queenprb5_d.x=2000;rookprb5_d.x=2000;elephprb5_d.x=2000;knightprb5_d.x=2000;queenprb6_d.x=2000;rookprb6_d.x=2000;elephprb6_d.x=2000;knightprb6_d.x=2000;queenprb7_d.x=2000;rookprb7_d.x=2000;elephprb7_d.x=2000;knightprb7_d.x=2000;queenprb8_d.x=2000;rookprb8_d.x=2000;elephprb8_d.x=2000;knightprb8_d.x=2000;
                            for(int i=0;i<8;i++){
                                for(int j=0;j<8;j++){
                                    switch(chess_board[i][j]){
                                        case -1:rook_d.x=j*100;rook_d.y=i*100;break;
                                        case -2:knight_d.x=j*100;knight_d.y=i*100;break;
                                        case -3:eleph_d.x=j*100;eleph_d.y=i*100;break;
                                        case -4:king_d.x=j*100;king_d.y=i*100;break;
                                        case -5:queen_d.x=j*100;queen_d.y=i*100;break;
                                        case -6:eleph2_d.x=j*100;eleph2_d.y=i*100;break;
                                        case -7:knight2_d.x=j*100;knight2_d.y=i*100;break;
                                        case -8:rook2_d.x=j*100;rook2_d.y=i*100;break;
                                        case -11:if(pr==0){pawn_d.x=j*100;pawn_d.y=i*100;}
                                                    else if(pr==1){queenpr_d.x=j*100;queenpr_d.y=i*100;queenpr_d.h=100;queenpr_d.w=100;}
                                                    else if(pr==2){rookpr_d.x=j*100;rookpr_d.y=i*100;rookpr_d.h=100;rookpr_d.w=100;}
                                                    else if(pr==3){elephpr_d.x=j*100;elephpr_d.y=i*100;elephpr_d.h=100;elephpr_d.w=100;}
                                                    else if(pr==4){knightpr_d.x=j*100;knightpr_d.y=i*100;knightpr_d.h=100;knightpr_d.w=100;}
                                                    break;
                                        case -12:if(pr2==0){pawn2_d.x=j*100;pawn2_d.y=i*100;}
                                                    else if(pr2==1){queenpr2_d.x=j*100;queenpr2_d.y=i*100;queenpr2_d.h=100;queenpr2_d.w=100;}
                                                    else if(pr2==2){rookpr2_d.x=j*100;rookpr2_d.y=i*100;rookpr2_d.h=100;rookpr2_d.w=100;}
                                                    else if(pr2==3){elephpr2_d.x=j*100;elephpr2_d.y=i*100;elephpr2_d.h=100;elephpr2_d.w=100;}
                                                    else if(pr2==4){knightpr2_d.x=j*100;knightpr2_d.y=i*100;knightpr2_d.h=100;knightpr2_d.w=100;}
                                                    break;
                                        case -13:if(pr3==0){pawn3_d.x=j*100;pawn3_d.y=i*100;}
                                                    else if(pr3==1){queenpr3_d.x=j*100;queenpr3_d.y=i*100;queenpr3_d.h=100;queenpr3_d.w=100;}
                                                    else if(pr3==2){rookpr3_d.x=j*100;rookpr3_d.y=i*100;rookpr3_d.h=100;rookpr3_d.w=100;}
                                                    else if(pr3==3){elephpr3_d.x=j*100;elephpr3_d.y=i*100;elephpr3_d.h=100;elephpr3_d.w=100;}
                                                    else if(pr3==4){knightpr3_d.x=j*100;knightpr3_d.y=i*100;knightpr3_d.h=100;knightpr3_d.w=100;}
                                                    break;
                                        case -14:if(pr4==0){pawn4_d.x=j*100;pawn4_d.y=i*100;}
                                                    else if(pr4==1){queenpr4_d.x=j*100;queenpr4_d.y=i*100;queenpr4_d.h=100;queenpr4_d.w=100;}
                                                    else if(pr4==2){rookpr4_d.x=j*100;rookpr4_d.y=i*100;rookpr4_d.h=100;rookpr4_d.w=100;}
                                                    else if(pr4==3){elephpr4_d.x=j*100;elephpr4_d.y=i*100;elephpr4_d.h=100;elephpr4_d.w=100;}
                                                    else if(pr4==4){knightpr4_d.x=j*100;knightpr4_d.y=i*100;knightpr4_d.h=100;knightpr4_d.w=100;}
                                                    break;
                                        case -15:if(pr5==0){pawn5_d.x=j*100;pawn5_d.y=i*100;}
                                                    else if(pr5==1){queenpr5_d.x=j*100;queenpr5_d.y=i*100;queenpr5_d.h=100;queenpr5_d.w=100;}
                                                    else if(pr5==2){rookpr5_d.x=j*100;rookpr5_d.y=i*100;rookpr5_d.h=100;rookpr5_d.w=100;}
                                                    else if(pr5==3){elephpr5_d.x=j*100;elephpr5_d.y=i*100;elephpr5_d.h=100;elephpr5_d.w=100;}
                                                    else if(pr5==4){knightpr5_d.x=j*100;knightpr5_d.y=i*100;knightpr5_d.h=100;knightpr5_d.w=100;}
                                                    break;
                                        case -16:if(pr6==0){pawn6_d.x=j*100;pawn6_d.y=i*100;}
                                                    else if(pr6==1){queenpr6_d.x=j*100;queenpr6_d.y=i*100;queenpr6_d.h=100;queenpr6_d.w=100;}
                                                    else if(pr6==2){rookpr6_d.x=j*100;rookpr6_d.y=i*100;rookpr6_d.h=100;rookpr6_d.w=100;}
                                                    else if(pr6==3){elephpr6_d.x=j*100;elephpr6_d.y=i*100;elephpr6_d.h=100;elephpr6_d.w=100;}
                                                    else if(pr6==4){knightpr6_d.x=j*100;knightpr6_d.y=i*100;knightpr6_d.h=100;knightpr6_d.w=100;}
                                                    break;
                                        case -17:if(pr7==0){pawn7_d.x=j*100;pawn7_d.y=i*100;}
                                                    else if(pr7==1){queenpr7_d.x=j*100;queenpr7_d.y=i*100;queenpr7_d.h=100;queenpr7_d.w=100;}
                                                    else if(pr7==2){rookpr7_d.x=j*100;rookpr7_d.y=i*100;rookpr7_d.h=100;rookpr7_d.w=100;}
                                                    else if(pr7==3){elephpr7_d.x=j*100;elephpr7_d.y=i*100;elephpr7_d.h=100;elephpr7_d.w=100;}
                                                    else if(pr7==4){knightpr7_d.x=j*100;knightpr7_d.y=i*100;knightpr7_d.h=100;knightpr7_d.w=100;}
                                                    break;
                                        case -18:if(pr8==0){pawn8_d.x=j*100;pawn8_d.y=i*100;}
                                                    else if(pr8==1){queenpr8_d.x=j*100;queenpr8_d.y=i*100;queenpr8_d.h=100;queenpr8_d.w=100;}
                                                    else if(pr8==2){rookpr8_d.x=j*100;rookpr8_d.y=i*100;rookpr8_d.h=100;rookpr8_d.w=100;}
                                                    else if(pr8==3){elephpr8_d.x=j*100;elephpr8_d.y=i*100;elephpr8_d.h=100;elephpr8_d.w=100;}
                                                    else if(pr8==4){knightpr8_d.x=j*100;knightpr8_d.y=i*100;knightpr8_d.h=100;knightpr8_d.w=100;}
                                                    break;
                                        case 61:if(prb==0){pawnb_d.x=j*100;pawnb_d.y=i*100;}
                                                    else if(prb==1){queenprb_d.x=j*100;queenprb_d.y=i*100;queenprb_d.h=100;queenprb_d.w=100;}
                                                    else if(prb==2){rookprb_d.x=j*100;rookprb_d.y=i*100;rookprb_d.h=100;rookprb_d.w=100;}
                                                    else if(prb==3){elephprb_d.x=j*100;elephprb_d.y=i*100;elephprb_d.h=100;elephprb_d.w=100;}
                                                    else if(prb==4){knightprb_d.x=j*100;knightprb_d.y=i*100;knightprb_d.h=100;knightprb_d.w=100;}
                                                    break;
                                        case 62:if(prb2==0){pawnb2_d.x=j*100;pawnb2_d.y=i*100;}
                                                    else if(prb2==1){queenprb2_d.x=j*100;queenprb2_d.y=i*100;queenprb2_d.h=100;queenprb2_d.w=100;}
                                                    else if(prb2==2){rookprb2_d.x=j*100;rookprb2_d.y=i*100;rookprb2_d.h=100;rookprb2_d.w=100;}
                                                    else if(prb2==3){elephprb2_d.x=j*100;elephprb2_d.y=i*100;elephprb2_d.h=100;elephprb2_d.w=100;}
                                                    else if(prb2==4){knightprb2_d.x=j*100;knightprb2_d.y=i*100;knightprb2_d.h=100;knightprb2_d.w=100;}
                                                    break;
                                        case 63:if(prb3==0){pawnb3_d.x=j*100;pawnb3_d.y=i*100;}
                                                    else if(prb3==1){queenprb3_d.x=j*100;queenprb3_d.y=i*100;queenprb3_d.h=100;queenprb3_d.w=100;}
                                                    else if(prb3==2){rookprb3_d.x=j*100;rookprb3_d.y=i*100;rookprb3_d.h=100;rookprb3_d.w=100;}
                                                    else if(prb3==3){elephprb3_d.x=j*100;elephprb3_d.y=i*100;elephprb3_d.h=100;elephprb3_d.w=100;}
                                                    else if(prb3==4){knightprb3_d.x=j*100;knightprb3_d.y=i*100;knightprb3_d.h=100;knightprb3_d.w=100;}
                                                    break;
                                        case 64:if(prb4==0){pawnb4_d.x=j*100;pawnb4_d.y=i*100;}
                                                    else if(prb4==1){queenprb4_d.x=j*100;queenprb4_d.y=i*100;queenprb4_d.h=100;queenprb4_d.w=100;}
                                                    else if(prb4==2){rookprb4_d.x=j*100;rookprb4_d.y=i*100;rookprb4_d.h=100;rookprb4_d.w=100;}
                                                    else if(prb4==3){elephprb4_d.x=j*100;elephprb4_d.y=i*100;elephprb4_d.h=100;elephprb4_d.w=100;}
                                                    else if(prb4==4){knightprb4_d.x=j*100;knightprb4_d.y=i*100;knightprb4_d.h=100;knightprb4_d.w=100;}
                                                    break;
                                        case 65:if(prb5==0){pawnb5_d.x=j*100;pawnb5_d.y=i*100;}
                                                    else if(prb5==1){queenprb5_d.x=j*100;queenprb5_d.y=i*100;queenprb5_d.h=100;queenprb5_d.w=100;}
                                                    else if(prb5==2){rookprb5_d.x=j*100;rookprb5_d.y=i*100;rookprb5_d.h=100;rookprb5_d.w=100;}
                                                    else if(prb5==3){elephprb5_d.x=j*100;elephprb5_d.y=i*100;elephprb5_d.h=100;elephprb5_d.w=100;}
                                                    else if(prb5==4){knightprb5_d.x=j*100;knightprb5_d.y=i*100;knightprb5_d.h=100;knightprb5_d.w=100;}
                                                    break;
                                        case 66:if(prb6==0){pawnb6_d.x=j*100;pawnb6_d.y=i*100;}
                                                    else if(prb6==1){queenprb6_d.x=j*100;queenprb6_d.y=i*100;queenprb6_d.h=100;queenprb6_d.w=100;}
                                                    else if(prb6==2){rookprb6_d.x=j*100;rookprb6_d.y=i*100;rookprb6_d.h=100;rookprb6_d.w=100;}
                                                    else if(prb6==3){elephprb6_d.x=j*100;elephprb6_d.y=i*100;elephprb6_d.h=100;elephprb6_d.w=100;}
                                                    else if(prb6==4){knightprb6_d.x=j*100;knightprb6_d.y=i*100;knightprb6_d.h=100;knightprb6_d.w=100;}
                                                    break;
                                        case 67:if(prb7==0){pawnb7_d.x=j*100;pawnb7_d.y=i*100;}
                                                    else if(prb7==1){queenprb7_d.x=j*100;queenprb7_d.y=i*100;queenprb7_d.h=100;queenprb7_d.w=100;}
                                                    else if(prb7==2){rookprb7_d.x=j*100;rookprb7_d.y=i*100;rookprb7_d.h=100;rookprb7_d.w=100;}
                                                    else if(prb7==3){elephprb7_d.x=j*100;elephprb7_d.y=i*100;elephprb7_d.h=100;elephprb7_d.w=100;}
                                                    else if(prb7==4){knightprb7_d.x=j*100;knightprb7_d.y=i*100;knightprb7_d.h=100;knightprb7_d.w=100;}
                                                    break;
                                        case 68:if(prb8==0){pawnb8_d.x=j*100;pawnb8_d.y=i*100;}
                                                    else if(prb8==1){queenprb8_d.x=j*100;queenprb8_d.y=i*100;queenprb8_d.h=100;queenprb8_d.w=100;}
                                                    else if(prb8==2){rookprb8_d.x=j*100;rookprb8_d.y=i*100;rookprb8_d.h=100;rookprb8_d.w=100;}
                                                    else if(prb8==3){elephprb8_d.x=j*100;elephprb8_d.y=i*100;elephprb8_d.h=100;elephprb8_d.w=100;}
                                                    else if(prb8==4){knightprb8_d.x=j*100;knightprb8_d.y=i*100;knightprb8_d.h=100;knightprb8_d.w=100;}
                                                    break;
                                        case 71:rookb_d.x=j*100;rookb_d.y=i*100;break;
                                        case 72:knightb_d.x=j*100;knightb_d.y=i*100;break;
                                        case 73:elephb_d.x=j*100;elephb_d.y=i*100;break;
                                        case 74:kingb_d.x=j*100;kingb_d.y=i*100;break;
                                        case 75:queenb_d.x=j*100;queenb_d.y=i*100;break;
                                        case 76:elephb2_d.x=j*100;elephb2_d.y=i*100;break;
                                        case 77:knightb2_d.x=j*100;knightb2_d.y=i*100;break;
                                        case 78:rookb2_d.x=j*100;rookb2_d.y=i*100;break;}}}a=1;}
                        else{
                        h=chess_board[y][x];flag=0,t=0;
                        for(i=0;i<8;i++){if((flag==1)||(t==1))break;
                          for(int j=0;j<8;j++){
                            if((chess_board[i][j]<0)&&(turn==0)){
                                    switch (chess_board[d][c]){
                                    case -1:
                                        kill=killed(d,c,y,x,chess_board);
                                        t=check(chess_board,d,c,y,x,kill,pr,pr2,pr3,pr4,pr5,pr6,pr7,pr8,prb,prb2,prb3,prb4,prb5,prb6,prb7,prb8);
                                        if(t==0){
                                        kill=killed(d,c,y,x,chess_board);
                                        flag=rook_moves(d,c,y,x,chess_board,kill);
                                        if(flag==1){
                                            castr1=1;
                                            textrect7.x=850;textrect7.y=300;
                                            chess_board[y][x]=chess_board[d][c];
                                            chess_board[d][c]=0;
                                            xx=x;yy=y;}
                                        if(kill==1&&flag==1){pp=remove_comp(h,pp);}
                                        if(flag==1){rook_d.x=x*100;rook_d.y=y*100;break;}
                                        else if(flag==0){textrect7.x=1200;textrect7.y=400;break;}}
                                        else if(t==1){textrect7.x=1200;textrect7.y=400;break;}
                                    case -2:
                                        kill=killed(d,c,y,x,chess_board);
                                        t=check(chess_board,d,c,y,x,kill,pr,pr2,pr3,pr4,pr5,pr6,pr7,pr8,prb,prb2,prb3,prb4,prb5,prb6,prb7,prb8);
                                        if(t==0){
                                            kill=killed(d,c,y,x,chess_board);
                                            flag=horse_moves(d,c,y,x,chess_board,kill);
                                            if(flag==1){
                                            textrect7.x=850;textrect7.y=300;
                                            chess_board[y][x]=chess_board[d][c];
                                            chess_board[d][c]=0;
                                            xx=x;yy=y;}
                                            if(kill==1&&flag==1){pp=remove_comp(h,pp);}
                                            if(flag==1){knight_d.x=x*100;knight_d.y=y*100;break;}
                                            else if(flag==0){textrect7.x=1200;textrect7.y=400;break;}}
                                        else if(t==1){textrect7.x=1200;textrect7.y=400;break;}
                                    case -3:
                                        kill=killed(d,c,y,x,chess_board);
                                        t=check(chess_board,d,c,y,x,kill,pr,pr2,pr3,pr4,pr5,pr6,pr7,pr8,prb,prb2,prb3,prb4,prb5,prb6,prb7,prb8);
                                        if(t==0){
                                        kill=killed(d,c,y,x,chess_board);
                                        flag=bishop_moves(d,c,y,x,chess_board,kill);
                                        if(flag==1){
                                        textrect7.x=850;textrect7.y=300;
                                        chess_board[y][x]=chess_board[d][c];
                                        chess_board[d][c]=0;
                                        xx=x;yy=y;}
                                        if(kill==1&&flag==1){pp=remove_comp(h,pp);}
                                        if(flag==1){eleph_d.x=x*100;eleph_d.y=y*100;break;}
                                        else if(flag==0){textrect7.x=1200;textrect7.y=400;break;}}
                                        else if(t==1){textrect7.x=1200;textrect7.y=400;break;}
                                    case -4:
                                        kill=killed(d,c,y,x,chess_board);
                                        t=check(chess_board,d,c,y,x,kill,pr,pr2,pr3,pr4,pr5,pr6,pr7,pr8,prb,prb2,prb3,prb4,prb5,prb6,prb7,prb8);
                                        if(t==0){
                                            kill=killed(d,c,y,x,chess_board);
                                            flag=0;
                                            if(((y==d && x==c+1)||(y==d && x==c-1)||(y==d+1 && x==c)||(y==d+1 && x==c+1)||(y==d+1 && x==c-1)||(y==d-1 && x==c)||(y==d-1 && x==c+1)||(y==d-1 && x==c-1))&&((x<8)&&(y<8))){flag=1;}
                                            if((chess_board[d][c]<0) && (chess_board[y][x]<0)){flag=0;}
                                            else if(chess_board[d][c]>0 && chess_board[y][x]>0){flag=0;}
                                            if(y==d && x==c+2 &&chess_board[y][c+1]==0&&chess_board[y][c+2]==0&&castk==0&&castr2==0){
                                             checkmate2=checkmate(chess_board,d,c,kill,pr,pr2,pr3,pr4,pr5,pr6,pr7,pr8,prb,prb2,prb3,prb4,prb5,prb6,prb7,prb8);
                                             checkmate3=check(chess_board,d,c,d,c+1,kill,pr,pr2,pr3,pr4,pr5,pr6,pr7,pr8,prb,prb2,prb3,prb4,prb5,prb6,prb7,prb8);
                                             if(checkmate2==0&&checkmate3==0){
                                                king_d.x=x*100;king_d.y=y*100;
                                                rook2_d.x=(x-1)*100;rook2_d.y=y*100;
                                                chess_board[y][x]=chess_board[d][c];
                                                k2cc=cc;castk=1;
                                                chess_board[d][c]=0;
                                                chess_board[y][x-1]=chess_board[0][7];
                                                chess_board[0][7]=0;flag=1;}
                                                else(flag=0);}
                                            else if(y==d && x==c-2&&chess_board[y][c-1]==0&&chess_board[y][c-2]==0&&castk==0&&castr1==0){
                                            checkmate2=checkmate(chess_board,d,c,kill,pr,pr2,pr3,pr4,pr5,pr6,pr7,pr8,prb,prb2,prb3,prb4,prb5,prb6,prb7,prb8);
                                            checkmate3=check(chess_board,d,c,d,c-1,kill,pr,pr2,pr3,pr4,pr5,pr6,pr7,pr8,prb,prb2,prb3,prb4,prb5,prb6,prb7,prb8);
                                             if(checkmate2==0&&checkmate3==0){
                                                king_d.x=x*100;king_d.y=y*100;
                                                rook_d.x=(x+1)*100;rook_d.y=y*100;
                                                chess_board[y][x]=chess_board[d][c];
                                                chess_board[d][c]=0;
                                                chess_board[y][x+1]=chess_board[0][0];
                                                k1cc=cc;castk=1;
                                                chess_board[0][0]=0;flag=1;}
                                                else(flag=0);}
                                            else if(flag==1){
                                                castk=1;
                                                textrect7.x=850;textrect7.y=300;
                                                chess_board[y][x]=chess_board[d][c];
                                                chess_board[d][c]=0;
                                                xx=x;yy=y;}
                                            if(kill==1&&flag==1){pp=remove_comp(h,pp);}
                                            if(flag==1){king_d.x=x*100;king_d.y=y*100;break;}
                                            else if(flag==0){textrect7.x=1200;textrect7.y=400;break;}}
                                        else if(t==1){textrect7.x=1200;textrect7.y=400;break;}
                                    case -5:
                                        kill=killed(d,c,y,x,chess_board);
                                        t=check(chess_board,d,c,y,x,kill,pr,pr2,pr3,pr4,pr5,pr6,pr7,pr8,prb,prb2,prb3,prb4,prb5,prb6,prb7,prb8);
                                        if(t==0){
                                        kill=killed(d,c,y,x,chess_board);
                                        flag=queen_moves(d,c,y,x,chess_board,kill);
                                        if(flag==1){
                                        textrect7.x=850;textrect7.y=300;
                                        chess_board[y][x]=chess_board[d][c];
                                        chess_board[d][c]=0;
                                        xx=x;yy=y;}
                                        if(kill==1&&flag==1){pp=remove_comp(h,pp);}
                                        if(flag==1){queen_d.x=x*100;queen_d.y=y*100;break;}
                                        else if(flag==0){textrect7.x=1200;textrect7.y=400;break;}}
                                        else if(t==1){textrect7.x=1200;textrect7.y=400;break;}
                                    case -6:
                                        kill=killed(d,c,y,x,chess_board);
                                        t=check(chess_board,d,c,y,x,kill,pr,pr2,pr3,pr4,pr5,pr6,pr7,pr8,prb,prb2,prb3,prb4,prb5,prb6,prb7,prb8);
                                        if(t==0){kill=killed(d,c,y,x,chess_board);
                                        flag=bishop_moves(d,c,y,x,chess_board,kill);
                                        if(flag==1){
                                        textrect7.x=850;textrect7.y=300;
                                        chess_board[y][x]=chess_board[d][c];
                                        chess_board[d][c]=0;
                                        xx=x;yy=y;}
                                        if(kill==1&&flag==1){pp=remove_comp(h,pp);}
                                        if(flag==1){eleph2_d.x=x*100;eleph2_d.y=y*100;break;}
                                        else if(flag==0){textrect7.x=1200;textrect7.y=400;break;}}
                                        else if(t==1){textrect7.x=1200;textrect7.y=400;break;}
                                    case -7:
                                        kill=killed(d,c,y,x,chess_board);
                                        t=check(chess_board,d,c,y,x,kill,pr,pr2,pr3,pr4,pr5,pr6,pr7,pr8,prb,prb2,prb3,prb4,prb5,prb6,prb7,prb8);
                                        if(t==0){
                                        kill=killed(d,c,y,x,chess_board);
                                        flag=horse_moves(d,c,y,x,chess_board,kill);
                                        if(flag==1){
                                        textrect7.x=850;textrect7.y=300;
                                        chess_board[y][x]=chess_board[d][c];
                                        chess_board[d][c]=0;
                                        xx=x;yy=y;}
                                        if(kill==1&&flag==1){pp=remove_comp(h,pp);}
                                            if(flag==1){knight2_d.x=x*100;knight2_d.y=y*100;break;}
                                            else if(flag==0){textrect7.x=1200;textrect7.y=400;break;}}
                                        else if(t==1){textrect7.x=1200;textrect7.y=400;break;}
                                    case -8:
                                        kill=killed(d,c,y,x,chess_board);
                                        t=check(chess_board,d,c,y,x,kill,pr,pr2,pr3,pr4,pr5,pr6,pr7,pr8,prb,prb2,prb3,prb4,prb5,prb6,prb7,prb8);
                                        if(t==0){
                                        kill=killed(d,c,y,x,chess_board);
                                        flag=rook_moves(d,c,y,x,chess_board,kill);
                                        if(flag==1){
                                        castr2=1;
                                        textrect7.x=850;textrect7.y=300;
                                        chess_board[y][x]=chess_board[d][c];
                                        chess_board[d][c]=0;
                                        xx=x;yy=y;}
                                        if(kill==1&&flag==1){pp=remove_comp(h,pp);}
                                        if(flag==1){rook2_d.x=x*100;rook2_d.y=y*100;break;}
                                        else if(flag==0){textrect7.x=1200;textrect7.y=400;break;}}
                                        else if(t==1){textrect7.x=1200;textrect7.y=400;break;}
                                    case -11:
                                        kill=killed(d,c,y,x,chess_board);
                                        t=check(chess_board,d,c,y,x,kill,pr,pr2,pr3,pr4,pr5,pr6,pr7,pr8,prb,prb2,prb3,prb4,prb5,prb6,prb7,prb8);
                                        if(t==0){
                                          kill=killed(d,c,y,x,chess_board);
                                          if(pr==0){flag=pawn_moves(kill,d,c,y,x,chess_board);}
                                          else if(pr==1){flag=queen_moves(d,c,y,x,chess_board,kill);}
                                          else if(pr==2){flag=rook_moves(d,c,y,x,chess_board,kill);}
                                          else if(pr==3){flag=bishop_moves(d,c,y,x,chess_board,kill);}
                                          else if(pr==4){flag=horse_moves(d,c,y,x,chess_board,kill);}
                                        if(flag==1){
                                        textrect7.x=850;textrect7.y=300;
                                        chess_board[y][x]=chess_board[d][c];
                                        chess_board[d][c]=0;
                                        xx=x;yy=y;}
                                        if(kill==1&&flag==1){pp=remove_comp(h,pp);}
                                        if(flag==1 && pr==0){
                                            pawn_d.x=x*100;pawn_d.y=y*100;
                                            z=promotion(flag,chess_board,x,y);
                                            if(z==1&&pr==0){
                                                do{
                                                printf(" congratulations, choose the number from 1 to 4 \n");
                                                printf(" 1 to queen \n 2 to rook \n 3 to eleph \n 4 to knight\n ");
                                                scanf("%d",&pr);
                                                switch(pr){
                                                case 1:
                                                    queenpr_d.x=x*100;queenpr_d.y=y*100;queenpr_d.w=100;queenpr_d.h=100;break;
                                                case 2:
                                                    rookpr_d.x=x*100;rookpr_d.y=y*100;rookpr_d.w=100;rookpr_d.h=100;break;
                                                case 3:
                                                    elephpr_d.x=x*100;elephpr_d.y=y*100;elephpr_d.w=100;elephpr_d.h=100;break;
                                                case 4:
                                                    knightpr_d.x=x*100;knightpr_d.y=y*100;knightpr_d.w=100;knightpr_d.h=100;break;}}
                                                while(pr!=1&&pr!=2&&pr!=3&&pr!=4);
                                                pawn_d=remove_comp(-11,pp);}break;}
                                        else if(flag==1&& pr==1){queenpr_d.x=x*100;queenpr_d.y=y*100;queenpr_d.w=100;queenpr_d.h=100;break;}
                                        else if(flag==1&& pr==2){rookpr_d.x=x*100;rookpr_d.y=y*100;rookpr_d.w=100;rookpr_d.h=100;break;}
                                        else if(flag==1&& pr==3){elephpr_d.x=x*100;elephpr_d.y=y*100;elephpr_d.w=100;elephpr_d.h=100;break;}
                                        else if(flag==1&& pr==4){knightpr_d.x=x*100;knightpr_d.y=y*100;knightpr_d.w=100;knightpr_d.h=100;break;}
                                        else if(flag==0){textrect7.x=1200;textrect7.y=400;break;}}
                                        else if(t==1){textrect7.x=1200;textrect7.y=400;break;}
                                    case -12:
                                        kill=killed(d,c,y,x,chess_board);
                                        t=check(chess_board,d,c,y,x,kill,pr,pr2,pr3,pr4,pr5,pr6,pr7,pr8,prb,prb2,prb3,prb4,prb5,prb6,prb7,prb8);
                                        if(t==0){
                                          kill=killed(d,c,y,x,chess_board);
                                          if(pr2==0){flag=pawn_moves(kill,d,c,y,x,chess_board);}
                                          else if(pr2==1){flag=queen_moves(d,c,y,x,chess_board,kill);}
                                          else if(pr2==2){flag=rook_moves(d,c,y,x,chess_board,kill);}
                                          else if(pr2==3){flag=bishop_moves(d,c,y,x,chess_board,kill);}
                                          else if(pr2==4){flag=horse_moves(d,c,y,x,chess_board,kill);}
                                        if(flag==1){
                                        textrect7.x=850;textrect7.y=300;
                                        chess_board[y][x]=chess_board[d][c];
                                        chess_board[d][c]=0;
                                        xx=x;yy=y;}
                                        if(kill==1&&flag==1){pp=remove_comp(h,pp);}
                                        if(flag==1 && pr2==0){
                                            pawn2_d.x=x*100;pawn2_d.y=y*100;
                                            z=promotion(flag,chess_board,x,y);
                                            if(z==1&&pr2==0){
                                                do{
                                                printf(" congratulations, choose the number from 1 to 4 \n");
                                                printf(" 1 to queen \n 2 to rook \n 3 to eleph \n 4 to knight\n ");
                                                scanf("%d",&pr2);
                                                switch(pr2){
                                                case 1:
                                                    queenpr2_d.x=x*100;queenpr2_d.y=y*100;queenpr2_d.w=100;queenpr2_d.h=100;break;
                                                case 2:
                                                    rookpr2_d.x=x*100;rookpr2_d.y=y*100;rookpr2_d.w=100;rookpr2_d.h=100;break;
                                                case 3:
                                                    elephpr2_d.x=x*100;elephpr2_d.y=y*100;elephpr2_d.w=100;elephpr2_d.h=100;break;
                                                case 4:
                                                    knightpr2_d.x=x*100;knightpr2_d.y=y*100;knightpr2_d.w=100;knightpr2_d.h=100;break;}}
                                                while(pr2!=1&&pr2!=2&&pr2!=3&&pr2!=4);
                                                pawn2_d=remove_comp(-12,pp);}break;}
                                        else if(flag==1&& pr2==1){queenpr2_d.x=x*100;queenpr2_d.y=y*100;queenpr2_d.w=100;queenpr2_d.h=100;break;}
                                        else if(flag==1&& pr2==2){rookpr2_d.x=x*100;rookpr2_d.y=y*100;rookpr2_d.w=100;rookpr2_d.h=100;break;}
                                        else if(flag==1&& pr2==3){elephpr2_d.x=x*100;elephpr2_d.y=y*100;elephpr2_d.w=100;elephpr2_d.h=100;break;}
                                        else if(flag==1&& pr2==4){knightpr2_d.x=x*100;knightpr2_d.y=y*100;knightpr2_d.w=100;knightpr2_d.h=100;break;}
                                        else if(flag==0){textrect7.x=1200;textrect7.y=400;break;}}
                                        else if(t==1){textrect7.x=1200;textrect7.y=400;break;}
                                    case -13:
                                        kill=killed(d,c,y,x,chess_board);
                                        t=check(chess_board,d,c,y,x,kill,pr,pr2,pr3,pr4,pr5,pr6,pr7,pr8,prb,prb2,prb3,prb4,prb5,prb6,prb7,prb8);
                                        if(t==0){
                                          kill=killed(d,c,y,x,chess_board);
                                          if(pr3==0){flag=pawn_moves(kill,d,c,y,x,chess_board);}
                                          else if(pr3==1){flag=queen_moves(d,c,y,x,chess_board,kill);}
                                          else if(pr3==2){flag=rook_moves(d,c,y,x,chess_board,kill);}
                                          else if(pr3==3){flag=bishop_moves(d,c,y,x,chess_board,kill);}
                                          else if(pr3==4){flag=horse_moves(d,c,y,x,chess_board,kill);}
                                        if(flag==1){
                                        textrect7.x=850;textrect7.y=300;
                                        chess_board[y][x]=chess_board[d][c];
                                        chess_board[d][c]=0;
                                        xx=x;yy=y;}
                                        if(kill==1&&flag==1){pp=remove_comp(h,pp);}
                                        if(flag==1 && pr3==0){
                                            pawn3_d.x=x*100;pawn3_d.y=y*100;
                                            z=promotion(flag,chess_board,x,y);
                                            if(z==1&&pr3==0){
                                               do{
                                                printf(" congratulations, choose the number from 1 to 4 \n");
                                                printf(" 1 to queen \n 2 to rook \n 3 to eleph \n 4 to knight\n ");
                                                scanf("%d",&pr3);
                                                switch(pr3){
                                                case 1:
                                                    queenpr3_d.x=x*100;queenpr3_d.y=y*100;queenpr3_d.w=100;queenpr3_d.h=100;break;
                                                case 2:
                                                    rookpr3_d.x=x*100;rookpr3_d.y=y*100;rookpr3_d.w=100;rookpr3_d.h=100;break;
                                                case 3:
                                                    elephpr3_d.x=x*100;elephpr3_d.y=y*100;elephpr3_d.w=100;elephpr3_d.h=100;break;
                                                case 4:
                                                    knightpr3_d.x=x*100;knightpr3_d.y=y*100;knightpr3_d.w=100;knightpr3_d.h=100;break;}}
                                                while(pr3!=1&&pr3!=2&&pr3!=3&&pr3!=4);
                                                pawn3_d=remove_comp(-13,pp);}break;}
                                        else if(flag==1&& pr3==1){queenpr3_d.x=x*100;queenpr3_d.y=y*100;queenpr3_d.w=100;queenpr3_d.h=100;break;}
                                        else if(flag==1&& pr3==2){rookpr3_d.x=x*100;rookpr3_d.y=y*100;rookpr3_d.w=100;rookpr3_d.h=100;break;}
                                        else if(flag==1&& pr3==3){elephpr3_d.x=x*100;elephpr3_d.y=y*100;elephpr3_d.w=100;elephpr3_d.h=100;break;}
                                        else if(flag==1&& pr3==4){knightpr3_d.x=x*100;knightpr3_d.y=y*100;knightpr3_d.w=100;knightpr3_d.h=100;break;}
                                        else if(flag==0){textrect7.x=1200;textrect7.y=400;break;}}
                                        else if(t==1){textrect7.x=1200;textrect7.y=400;break;}
                                    case -14:
                                        kill=killed(d,c,y,x,chess_board);
                                        t=check(chess_board,d,c,y,x,kill,pr,pr2,pr3,pr4,pr5,pr6,pr7,pr8,prb,prb2,prb3,prb4,prb5,prb6,prb7,prb8);
                                        if(t==0){
                                          kill=killed(d,c,y,x,chess_board);
                                          if(pr4==0){flag=pawn_moves(kill,d,c,y,x,chess_board);}
                                          else if(pr4==1){flag=queen_moves(d,c,y,x,chess_board,kill);}
                                          else if(pr4==2){flag=rook_moves(d,c,y,x,chess_board,kill);}
                                          else if(pr4==3){flag=bishop_moves(d,c,y,x,chess_board,kill);}
                                          else if(pr4==4){flag=horse_moves(d,c,y,x,chess_board,kill);}
                                        if(flag==1){
                                        textrect7.x=850;textrect7.y=300;
                                        chess_board[y][x]=chess_board[d][c];
                                        chess_board[d][c]=0;
                                        xx=x;yy=y;}
                                        if(kill==1&&flag==1){pp=remove_comp(h,pp);}
                                        if(flag==1 && pr4==0){
                                            pawn4_d.x=x*100;pawn4_d.y=y*100;
                                            z=promotion(flag,chess_board,x,y);
                                            if(z==1&&pr4==0){
                                               do{
                                                printf(" congratulations, choose the number from 1 to 4 \n");
                                                printf(" 1 to queen \n 2 to rook \n 3 to eleph \n 4 to knight\n ");
                                                scanf("%d",&pr4);
                                                switch(pr4){
                                                case 1:
                                                    queenpr4_d.x=x*100;queenpr4_d.y=y*100;queenpr4_d.w=100;queenpr4_d.h=100;break;
                                                case 2:
                                                    rookpr4_d.x=x*100;rookpr4_d.y=y*100;rookpr4_d.w=100;rookpr4_d.h=100;break;
                                                case 3:
                                                    elephpr4_d.x=x*100;elephpr4_d.y=y*100;elephpr4_d.w=100;elephpr4_d.h=100;break;
                                                case 4:
                                                    knightpr4_d.x=x*100;knightpr4_d.y=y*100;knightpr4_d.w=100;knightpr4_d.h=100;break;}}
                                                while(pr4!=1&&pr4!=2&&pr4!=3&&pr4!=4);
                                                pawn4_d=remove_comp(-14,pp);}break;}
                                        else if(flag==1&& pr4==1){queenpr4_d.x=x*100;queenpr4_d.y=y*100;queenpr4_d.w=100;queenpr4_d.h=100;break;}
                                        else if(flag==1&& pr4==2){rookpr4_d.x=x*100;rookpr4_d.y=y*100;rookpr4_d.w=100;rookpr4_d.h=100;break;}
                                        else if(flag==1&& pr4==3){elephpr4_d.x=x*100;elephpr4_d.y=y*100;elephpr4_d.w=100;elephpr4_d.h=100;break;}
                                        else if(flag==1&& pr4==4){knightpr4_d.x=x*100;knightpr4_d.y=y*100;knightpr4_d.w=100;knightpr4_d.h=100;break;}
                                        else if(flag==0){textrect7.x=1200;textrect7.y=400;break;}}
                                        else if(t==1){textrect7.x=1200;textrect7.y=400;break;}
                                    case -15:
                                        kill=killed(d,c,y,x,chess_board);
                                        t=check(chess_board,d,c,y,x,kill,pr,pr2,pr3,pr4,pr5,pr6,pr7,pr8,prb,prb2,prb3,prb4,prb5,prb6,prb7,prb8);
                                        if(t==0){
                                          kill=killed(d,c,y,x,chess_board);
                                          if(pr5==0){flag=pawn_moves(kill,d,c,y,x,chess_board);}
                                          else if(pr5==1){flag=queen_moves(d,c,y,x,chess_board,kill);}
                                          else if(pr5==2){flag=rook_moves(d,c,y,x,chess_board,kill);}
                                          else if(pr5==3){flag=bishop_moves(d,c,y,x,chess_board,kill);}
                                          else if(pr5==4){flag=horse_moves(d,c,y,x,chess_board,kill);}
                                        if(flag==1){
                                        textrect7.x=850;textrect7.y=300;
                                        chess_board[y][x]=chess_board[d][c];
                                        chess_board[d][c]=0;
                                        xx=x;yy=y;}
                                        if(kill==1&&flag==1){pp=remove_comp(h,pp);}
                                        if(flag==1 && pr5==0){
                                            pawn5_d.x=x*100;pawn5_d.y=y*100;
                                            z=promotion(flag,chess_board,x,y);
                                            if(z==1&&pr5==0){
                                                do{
                                                printf(" congratulations, choose the number from 1 to 4 \n");
                                                printf(" 1 to queen \n 2 to rook \n 3 to eleph \n 4 to knight\n ");
                                                scanf("%d",&pr5);
                                                switch(pr5){
                                                case 1:
                                                    queenpr5_d.x=x*100;queenpr5_d.y=y*100;queenpr5_d.w=100;queenpr5_d.h=100;break;
                                                case 2:
                                                    rookpr5_d.x=x*100;rookpr5_d.y=y*100;rookpr5_d.w=100;rookpr5_d.h=100;break;
                                                case 3:
                                                    elephpr5_d.x=x*100;elephpr5_d.y=y*100;elephpr5_d.w=100;elephpr5_d.h=100;break;
                                                case 4:
                                                    knightpr5_d.x=x*100;knightpr5_d.y=y*100;knightpr5_d.w=100;knightpr5_d.h=100;break;}}
                                                while(pr5!=1&&pr5!=2&&pr5!=3&&pr5!=4);
                                                pawn5_d=remove_comp(-15,pp);}break;}
                                        else if(flag==1&& pr5==1){queenpr5_d.x=x*100;queenpr5_d.y=y*100;queenpr5_d.w=100;queenpr5_d.h=100;break;}
                                        else if(flag==1&& pr5==2){rookpr5_d.x=x*100;rookpr5_d.y=y*100;rookpr5_d.w=100;rookpr5_d.h=100;break;}
                                        else if(flag==1&& pr5==3){elephpr5_d.x=x*100;elephpr5_d.y=y*100;elephpr5_d.w=100;elephpr5_d.h=100;break;}
                                        else if(flag==1&& pr5==4){knightpr5_d.x=x*100;knightpr5_d.y=y*100;knightpr5_d.w=100;knightpr5_d.h=100;break;}
                                        else if(flag==0){textrect7.x=1200;textrect7.y=400;break;}}
                                        else if(t==1){textrect7.x=1200;textrect7.y=400;break;}
                                    case -16:
                                        kill=killed(d,c,y,x,chess_board);
                                        t=check(chess_board,d,c,y,x,kill,pr,pr2,pr3,pr4,pr5,pr6,pr7,pr8,prb,prb2,prb3,prb4,prb5,prb6,prb7,prb8);
                                        if(t==0){
                                          kill=killed(d,c,y,x,chess_board);
                                          if(pr6==0){flag=pawn_moves(kill,d,c,y,x,chess_board);}
                                          else if(pr6==1){flag=queen_moves(d,c,y,x,chess_board,kill);}
                                          else if(pr6==2){flag=rook_moves(d,c,y,x,chess_board,kill);}
                                          else if(pr6==3){flag=bishop_moves(d,c,y,x,chess_board,kill);}
                                          else if(pr6==4){flag=horse_moves(d,c,y,x,chess_board,kill);}
                                        if(flag==1){
                                        textrect7.x=850;textrect7.y=300;
                                        chess_board[y][x]=chess_board[d][c];
                                        chess_board[d][c]=0;
                                        xx=x;yy=y;}
                                        if(kill==1&&flag==1){pp=remove_comp(h,pp);}
                                        if(flag==1 && pr6==0){
                                            pawn6_d.x=x*100;pawn6_d.y=y*100;
                                            z=promotion(flag,chess_board,x,y);
                                            if(z==1&&pr6==0){
                                                do{
                                                printf(" congratulations, choose the number from 1 to 4 \n");
                                                printf(" 1 to queen \n 2 to rook \n 3 to eleph \n 4 to knight\n ");
                                                scanf("%d",&pr6);
                                                switch(pr6){
                                                case 1:
                                                    queenpr6_d.x=x*100;queenpr6_d.y=y*100;queenpr6_d.w=100;queenpr6_d.h=100;break;
                                                case 2:
                                                    rookpr6_d.x=x*100;rookpr6_d.y=y*100;rookpr6_d.w=100;rookpr6_d.h=100;break;
                                                case 3:
                                                    elephpr6_d.x=x*100;elephpr6_d.y=y*100;elephpr6_d.w=100;elephpr6_d.h=100;break;
                                                case 4:
                                                    knightpr6_d.x=x*100;knightpr6_d.y=y*100;knightpr6_d.w=100;knightpr6_d.h=100;break;}}
                                                while(pr6!=1&&pr6!=2&&pr6!=3&&pr6!=4);
                                                pawn6_d=remove_comp(-16,pp);}break;}
                                        else if(flag==1&& pr6==1){queenpr6_d.x=x*100;queenpr6_d.y=y*100;queenpr6_d.w=100;queenpr6_d.h=100;break;}
                                        else if(flag==1&& pr6==2){rookpr6_d.x=x*100;rookpr6_d.y=y*100;rookpr6_d.w=100;rookpr6_d.h=100;break;}
                                        else if(flag==1&& pr6==3){elephpr6_d.x=x*100;elephpr6_d.y=y*100;elephpr6_d.w=100;elephpr6_d.h=100;break;}
                                        else if(flag==1&& pr6==4){knightpr6_d.x=x*100;knightpr6_d.y=y*100;knightpr6_d.w=100;knightpr6_d.h=100;break;}
                                        else if(flag==0){textrect7.x=1200;textrect7.y=400;break;}}
                                        else if(t==1){textrect7.x=1200;textrect7.y=400;break;}
                                    case -17:
                                        kill=killed(d,c,y,x,chess_board);
                                        t=check(chess_board,d,c,y,x,kill,pr,pr2,pr3,pr4,pr5,pr6,pr7,pr8,prb,prb2,prb3,prb4,prb5,prb6,prb7,prb8);
                                        if(t==0){
                                          kill=killed(d,c,y,x,chess_board);
                                          if(pr7==0){flag=pawn_moves(kill,d,c,y,x,chess_board);}
                                          else if(pr7==1){flag=queen_moves(d,c,y,x,chess_board,kill);}
                                          else if(pr7==2){flag=rook_moves(d,c,y,x,chess_board,kill);}
                                          else if(pr7==3){flag=bishop_moves(d,c,y,x,chess_board,kill);}
                                          else if(pr7==4){flag=horse_moves(d,c,y,x,chess_board,kill);}
                                        if(flag==1){
                                        textrect7.x=850;textrect7.y=300;
                                        chess_board[y][x]=chess_board[d][c];
                                        chess_board[d][c]=0;
                                        xx=x;yy=y;}
                                        if(kill==1&&flag==1){pp=remove_comp(h,pp);}
                                        if(flag==1 && pr7==0){
                                            pawn7_d.x=x*100;pawn7_d.y=y*100;
                                            z=promotion(flag,chess_board,x,y);
                                            if(z==1&&pr7==0){
                                                do{
                                                printf(" congratulations, choose the number from 1 to 4 \n");
                                                printf(" 1 to queen \n 2 to rook \n 3 to eleph \n 4 to knight\n ");
                                                scanf("%d",&pr7);
                                                switch(pr7){
                                                case 1:
                                                    queenpr7_d.x=x*100;queenpr7_d.y=y*100;queenpr7_d.w=100;queenpr7_d.h=100;break;
                                                case 2:
                                                    rookpr7_d.x=x*100;rookpr7_d.y=y*100;rookpr7_d.w=100;rookpr7_d.h=100;break;
                                                case 3:
                                                    elephpr7_d.x=x*100;elephpr7_d.y=y*100;elephpr7_d.w=100;elephpr7_d.h=100;break;
                                                case 4:
                                                    knightpr7_d.x=x*100;knightpr7_d.y=y*100;knightpr7_d.w=100;knightpr7_d.h=100;break;}}
                                                while(pr7!=1&&pr7!=2&&pr7!=3&&pr7!=4);
                                                pawn7_d=remove_comp(-17,pp);}break;}
                                        else if(flag==1&& pr7==1){queenpr7_d.x=x*100;queenpr7_d.y=y*100;queenpr7_d.w=100;queenpr7_d.h=100;break;}
                                        else if(flag==1&& pr7==2){rookpr7_d.x=x*100;rookpr7_d.y=y*100;rookpr7_d.w=100;rookpr7_d.h=100;break;}
                                        else if(flag==1&& pr7==3){elephpr7_d.x=x*100;elephpr7_d.y=y*100;elephpr7_d.w=100;elephpr7_d.h=100;break;}
                                        else if(flag==1&& pr7==4){knightpr7_d.x=x*100;knightpr7_d.y=y*100;knightpr7_d.w=100;knightpr7_d.h=100;break;}
                                        else if(flag==0){textrect7.x=1200;textrect7.y=400;break;}}
                                        else if(t==1){textrect7.x=1200;textrect7.y=400;break;}
                                    case -18:
                                        kill=killed(d,c,y,x,chess_board);
                                        t=check(chess_board,d,c,y,x,kill,pr,pr2,pr3,pr4,pr5,pr6,pr7,pr8,prb,prb2,prb3,prb4,prb5,prb6,prb7,prb8);
                                        if(t==0){
                                          kill=killed(d,c,y,x,chess_board);
                                          if(pr8==0){flag=pawn_moves(kill,d,c,y,x,chess_board);}
                                          else if(pr8==1){flag=queen_moves(d,c,y,x,chess_board,kill);}
                                          else if(pr8==2){flag=rook_moves(d,c,y,x,chess_board,kill);}
                                          else if(pr8==3){flag=bishop_moves(d,c,y,x,chess_board,kill);}
                                          else if(pr8==4){flag=horse_moves(d,c,y,x,chess_board,kill);}
                                        if(flag==1){
                                        textrect7.x=850;textrect7.y=300;
                                        chess_board[y][x]=chess_board[d][c];
                                        chess_board[d][c]=0;
                                        xx=x;yy=y;}
                                        if(kill==1&&flag==1){pp=remove_comp(h,pp);}
                                        if(flag==1 && pr8==0){
                                            pawn8_d.x=x*100;pawn8_d.y=y*100;
                                            z=promotion(flag,chess_board,x,y);
                                            if(z==1&&pr8==0){
                                                do{
                                                printf(" congratulations, choose the number from 1 to 4 \n");
                                                printf(" 1 to queen \n 2 to rook \n 3 to eleph \n 4 to knight\n ");
                                                scanf("%d",&pr8);
                                                switch(pr8){
                                                case 1:
                                                    queenpr8_d.x=x*100;queenpr8_d.y=y*100;queenpr8_d.w=100;queenpr8_d.h=100;break;
                                                case 2:
                                                    rookpr8_d.x=x*100;rookpr8_d.y=y*100;rookpr8_d.w=100;rookpr8_d.h=100;break;
                                                case 3:
                                                    elephpr8_d.x=x*100;elephpr8_d.y=y*100;elephpr8_d.w=100;elephpr8_d.h=100;break;
                                                case 4:
                                                    knightpr8_d.x=x*100;knightpr8_d.y=y*100;knightpr8_d.w=100;knightpr8_d.h=100;break;}}
                                                while(pr8!=1&&pr8!=2&&pr8!=3&&pr8!=4);
                                                pawn8_d=remove_comp(-18,pp);}break;}
                                        else if(flag==1&& pr8==1){queenpr8_d.x=x*100;queenpr8_d.y=y*100;queenpr8_d.w=100;queenpr8_d.h=100;break;}
                                        else if(flag==1&& pr8==2){rookpr8_d.x=x*100;rookpr8_d.y=y*100;rookpr8_d.w=100;rookpr8_d.h=100;break;}
                                        else if(flag==1&& pr8==3){elephpr8_d.x=x*100;elephpr8_d.y=y*100;elephpr8_d.w=100;elephpr8_d.h=100;break;}
                                        else if(flag==1&& pr8==4){knightpr_d.x=x*100;knightpr_d.y=y*100;knightpr8_d.w=100;knightpr8_d.h=100;break;}
                                        else if(flag==0){textrect7.x=1200;textrect7.y=400;break;}}
                                        else if(t==1){textrect7.x=1200;textrect7.y=400;break;}}
                                        if(flag==1){turn=1;textrect2.x=850;textrect2.y=400;textrect.x=850;textrect.y=300;}
                                        if((flag==1)||(t==1))break;}
                            else if((chess_board[i][j]>0)&&(turn==1)){
                                    switch (chess_board[d][c]){
                                    case 61:
                                         kill=killed(d,c,y,x,chess_board);
                                        t=check(chess_board,d,c,y,x,kill,pr,pr2,pr3,pr4,pr5,pr6,pr7,pr8,prb,prb2,prb3,prb4,prb5,prb6,prb7,prb8);
                                        if(t==0){
                                          kill=killed(d,c,y,x,chess_board);
                                          if(prb==0){flag=pawn_moves(kill,d,c,y,x,chess_board);}
                                          else if(prb==1){flag=queen_moves(d,c,y,x,chess_board,kill);}
                                          else if(prb==2){flag=rook_moves(d,c,y,x,chess_board,kill);}
                                          else if(prb==3){flag=bishop_moves(d,c,y,x,chess_board,kill);}
                                          else if(prb==4){flag=horse_moves(d,c,y,x,chess_board,kill);}
                                        if(flag==1){
                                        textrect7.x=850;textrect7.y=300;
                                        chess_board[y][x]=chess_board[d][c];
                                        chess_board[d][c]=0;
                                        xx=x;yy=y;}
                                        if(kill==1&&flag==1){pp=remove_comp(h,pp);}
                                        if(flag==1 && prb==0){
                                            pawnb_d.x=x*100;pawnb_d.y=y*100;
                                            z=promotion(flag,chess_board,x,y);
                                            if(z==1&&prb==0){
                                                do{
                                                printf(" congratulations, choose the number from 1 to 4 \n");
                                                printf(" 1 to queen \n 2 to rook \n 3 to eleph \n 4 to knight\n ");
                                                scanf("%d",&prb);
                                                switch(prb){
                                                case 1:
                                                    queenprb_d.x=x*100;queenprb_d.y=y*100;queenprb_d.w=100;queenprb_d.h=100;break;
                                                case 2:
                                                    rookprb_d.x=x*100;rookprb_d.y=y*100;rookprb_d.w=100;rookprb_d.h=100;break;
                                                case 3:
                                                    elephprb_d.x=x*100;elephprb_d.y=y*100;elephprb_d.w=100;elephprb_d.h=100;break;
                                                case 4:
                                                    knightprb_d.x=x*100;knightprb_d.y=y*100;knightprb_d.w=100;knightprb_d.h=100;break;}}
                                                while(prb!=1&&prb!=2&&prb!=3&&prb!=4);
                                                pawnb_d=remove_comp(61,pp);}
                                            break;}
                                        else if(flag==1&& prb==1){queenprb_d.x=x*100;queenprb_d.y=y*100;queenprb_d.w=100;queenprb_d.h=100;break;}
                                        else if(flag==1&& prb==2){rookprb_d.x=x*100;rookprb_d.y=y*100;rookprb_d.w=100;rookprb_d.h=100;break;}
                                        else if(flag==1&& prb==3){elephprb_d.x=x*100;elephprb_d.y=y*100;elephprb_d.w=100;elephprb_d.h=100;break;}
                                        else if(flag==1&& prb==4){knightprb_d.x=x*100;knightprb_d.y=y*100;knightprb_d.w=100;knightprb_d.h=100;break;}
                                        else if(flag==0){textrect7.x=1200;textrect7.y=400;break;}}
                                        else if(t==1){textrect7.x=1200;textrect7.y=400;break;}
                                    case 62:
                                        kill=killed(d,c,y,x,chess_board);
                                        t=check(chess_board,d,c,y,x,kill,pr,pr2,pr3,pr4,pr5,pr6,pr7,pr8,prb,prb2,prb3,prb4,prb5,prb6,prb7,prb8);
                                        if(t==0){
                                          kill=killed(d,c,y,x,chess_board);
                                          if(prb2==0){flag=pawn_moves(kill,d,c,y,x,chess_board);}
                                          else if(prb2==1){flag=queen_moves(d,c,y,x,chess_board,kill);}
                                          else if(prb2==2){flag=rook_moves(d,c,y,x,chess_board,kill);}
                                          else if(prb2==3){flag=bishop_moves(d,c,y,x,chess_board,kill);}
                                          else if(prb2==4){flag=horse_moves(d,c,y,x,chess_board,kill);}
                                        if(flag==1){
                                        textrect7.x=850;textrect7.y=300;
                                        chess_board[y][x]=chess_board[d][c];
                                        chess_board[d][c]=0;
                                        xx=x;yy=y;}
                                        if(kill==1&&flag==1){pp=remove_comp(h,pp);}
                                        if(flag==1 && prb2==0){
                                            pawnb2_d.x=x*100;pawnb2_d.y=y*100;
                                            z=promotion(flag,chess_board,x,y);
                                            if(z==1&&prb2==0){
                                                do{
                                                printf(" congratulations, choose the number from 1 to 4 \n");
                                                printf(" 1 to queen \n 2 to rook \n 3 to eleph \n 4 to knight\n ");
                                                scanf("%d",&prb2);
                                                switch(prb2){
                                                case 1:
                                                    queenprb2_d.x=x*100;queenprb2_d.y=y*100;queenprb2_d.w=100;queenprb2_d.h=100;break;
                                                case 2:
                                                    rookprb2_d.x=x*100;rookprb2_d.y=y*100;rookprb2_d.w=100;rookprb2_d.h=100;break;
                                                case 3:
                                                    elephprb2_d.x=x*100;elephprb2_d.y=y*100;elephprb2_d.w=100;elephprb2_d.h=100;break;
                                                case 4:
                                                    knightprb2_d.x=x*100;knightprb2_d.y=y*100;knightprb2_d.w=100;knightprb2_d.h=100;break;}}
                                                while(prb2!=1&&prb2!=2&&prb2!=3&&prb2!=4);
                                                pawnb2_d=remove_comp(62,pp);}break;}
                                        else if(flag==1&& prb2==1){queenprb2_d.x=x*100;queenprb2_d.y=y*100;queenprb2_d.w=100;queenprb2_d.h=100;break;}
                                        else if(flag==1&& prb2==2){rookprb2_d.x=x*100;rookprb2_d.y=y*100;rookprb2_d.w=100;rookprb2_d.h=100;break;}
                                        else if(flag==1&& prb2==3){elephprb2_d.x=x*100;elephprb2_d.y=y*100;elephprb2_d.w=100;elephprb2_d.h=100;break;}
                                        else if(flag==1&& prb2==4){knightprb2_d.x=x*100;knightprb2_d.y=y*100;knightprb2_d.w=100;knightprb2_d.h=100;break;}
                                        else if(flag==0){textrect7.x=1200;textrect7.y=400;break;}}
                                        else if(t==1){textrect7.x=1200;textrect7.y=400;break;}
                                    case 63:
                                        kill=killed(d,c,y,x,chess_board);
                                        t=check(chess_board,d,c,y,x,kill,pr,pr2,pr3,pr4,pr5,pr6,pr7,pr8,prb,prb2,prb3,prb4,prb5,prb6,prb7,prb8);
                                        if(t==0){
                                          kill=killed(d,c,y,x,chess_board);
                                          if(prb3==0){flag=pawn_moves(kill,d,c,y,x,chess_board);}
                                          else if(prb3==1){flag=queen_moves(d,c,y,x,chess_board,kill);}
                                          else if(prb3==2){flag=rook_moves(d,c,y,x,chess_board,kill);}
                                          else if(prb3==3){flag=bishop_moves(d,c,y,x,chess_board,kill);}
                                          else if(prb3==4){flag=horse_moves(d,c,y,x,chess_board,kill);}
                                        if(flag==1){
                                        textrect7.x=850;textrect7.y=300;
                                        chess_board[y][x]=chess_board[d][c];
                                        chess_board[d][c]=0;
                                        xx=x;yy=y;}
                                        if(kill==1&&flag==1){pp=remove_comp(h,pp);}
                                        if(flag==1 && prb3==0){
                                            pawnb3_d.x=x*100;pawnb3_d.y=y*100;
                                            z=promotion(flag,chess_board,x,y);
                                            if(z==1&&prb3==0){
                                               do{
                                                printf(" congratulations, choose the number from 1 to 4 \n");
                                                printf(" 1 to queen \n 2 to rook \n 3 to eleph \n 4 to knight\n ");
                                                scanf("%d",&prb3);
                                                switch(prb3){
                                                case 1:
                                                    queenprb3_d.x=x*100;queenprb3_d.y=y*100;queenprb3_d.w=100;queenprb3_d.h=100;break;
                                                case 2:
                                                    rookprb3_d.x=x*100;rookprb3_d.y=y*100;rookprb3_d.w=100;rookprb3_d.h=100;break;
                                                case 3:
                                                    elephprb3_d.x=x*100;elephprb3_d.y=y*100;elephprb3_d.w=100;elephprb3_d.h=100;break;
                                                case 4:
                                                    knightprb3_d.x=x*100;knightprb3_d.y=y*100;knightprb3_d.w=100;knightprb3_d.h=100;break;}}
                                                while(prb3!=1&&prb3!=2&&prb3!=3&&prb3!=4);
                                                pawnb3_d=remove_comp(63,pp);}break;}
                                        else if(flag==1&& prb3==1){queenprb3_d.x=x*100;queenprb3_d.y=y*100;queenprb3_d.w=100;queenprb3_d.h=100;break;}
                                        else if(flag==1&& prb3==2){rookprb3_d.x=x*100;rookprb3_d.y=y*100;rookprb3_d.w=100;rookprb3_d.h=100;break;}
                                        else if(flag==1&& prb3==3){elephprb3_d.x=x*100;elephprb3_d.y=y*100;elephprb3_d.w=100;elephprb3_d.h=100;break;}
                                        else if(flag==1&& prb3==4){knightprb3_d.x=x*100;knightprb3_d.y=y*100;knightprb3_d.w=100;knightprb3_d.h=100;break;}
                                        else if(flag==0){textrect7.x=1200;textrect7.y=400;break;}}
                                        else if(t==1){textrect7.x=1200;textrect7.y=400;break;}
                                    case 64:
                                        kill=killed(d,c,y,x,chess_board);
                                        t=check(chess_board,d,c,y,x,kill,pr,pr2,pr3,pr4,pr5,pr6,pr7,pr8,prb,prb2,prb3,prb4,prb5,prb6,prb7,prb8);
                                        if(t==0){
                                          kill=killed(d,c,y,x,chess_board);
                                          if(prb4==0){flag=pawn_moves(kill,d,c,y,x,chess_board);}
                                          else if(prb4==1){flag=queen_moves(d,c,y,x,chess_board,kill);}
                                          else if(prb4==2){flag=rook_moves(d,c,y,x,chess_board,kill);}
                                          else if(prb4==3){flag=bishop_moves(d,c,y,x,chess_board,kill);}
                                          else if(prb4==4){flag=horse_moves(d,c,y,x,chess_board,kill);}
                                        if(flag==1){
                                        textrect7.x=850;textrect7.y=300;
                                        chess_board[y][x]=chess_board[d][c];
                                        chess_board[d][c]=0;
                                        xx=x;yy=y;}
                                        if(kill==1&&flag==1){pp=remove_comp(h,pp);}
                                        if(flag==1 && prb4==0){
                                            pawnb4_d.x=x*100;pawnb4_d.y=y*100;
                                            z=promotion(flag,chess_board,x,y);
                                            if(z==1&&prb4==0){
                                                do{
                                                printf(" congratulations, choose the number from 1 to 4 \n");
                                                printf(" 1 to queen \n 2 to rook \n 3 to eleph \n 4 to knight\n ");
                                                scanf("%d",&prb4);
                                                switch(prb4){
                                                case 1:
                                                    queenprb4_d.x=x*100;queenprb4_d.y=y*100;queenprb4_d.w=100;queenprb4_d.h=100;break;
                                                case 2:
                                                    rookprb4_d.x=x*100;rookprb4_d.y=y*100;rookprb4_d.w=100;rookprb4_d.h=100;break;
                                                case 3:
                                                    elephprb4_d.x=x*100;elephprb4_d.y=y*100;elephprb4_d.w=100;elephprb4_d.h=100;break;
                                                case 4:
                                                    knightprb4_d.x=x*100;knightprb4_d.y=y*100;knightprb4_d.w=100;knightprb4_d.h=100;break;}}
                                                while(prb4!=1&&prb4!=2&&prb4!=3&&prb4!=4);
                                                pawnb4_d=remove_comp(64,pp);}break;}
                                        else if(flag==1&& prb4==1){queenprb4_d.x=x*100;queenprb4_d.y=y*100;queenprb4_d.w=100;queenprb4_d.h=100;break;}
                                        else if(flag==1&& prb4==2){rookprb4_d.x=x*100;rookprb4_d.y=y*100;rookprb4_d.w=100;rookprb4_d.h=100;break;}
                                        else if(flag==1&& prb4==3){elephprb4_d.x=x*100;elephprb4_d.y=y*100;elephprb4_d.w=100;elephprb4_d.h=100;break;}
                                        else if(flag==1&& prb4==4){knightprb4_d.x=x*100;knightprb4_d.y=y*100;knightprb4_d.w=100;knightprb4_d.h=100;break;}
                                        else if(flag==0){textrect7.x=1200;textrect7.y=400;break;}}
                                        else if(t==1){textrect7.x=1200;textrect7.y=400;break;}
                                    case 65:
                                        kill=killed(d,c,y,x,chess_board);
                                        t=check(chess_board,d,c,y,x,kill,pr,pr2,pr3,pr4,pr5,pr6,pr7,pr8,prb,prb2,prb3,prb4,prb5,prb6,prb7,prb8);
                                        if(t==0){
                                          kill=killed(d,c,y,x,chess_board);
                                          if(prb5==0){flag=pawn_moves(kill,d,c,y,x,chess_board);}
                                          else if(prb5==1){flag=queen_moves(d,c,y,x,chess_board,kill);}
                                          else if(prb5==2){flag=rook_moves(d,c,y,x,chess_board,kill);}
                                          else if(prb5==3){flag=bishop_moves(d,c,y,x,chess_board,kill);}
                                          else if(prb5==4){flag=horse_moves(d,c,y,x,chess_board,kill);}
                                        if(flag==1){
                                        textrect7.x=850;textrect7.y=300;
                                        chess_board[y][x]=chess_board[d][c];
                                        chess_board[d][c]=0;
                                        xx=x;yy=y;}
                                        if(kill==1&&flag==1){pp=remove_comp(h,pp);}
                                        if(flag==1 && prb5==0){
                                            pawnb5_d.x=x*100;pawnb5_d.y=y*100;
                                            z=promotion(flag,chess_board,x,y);
                                            if(z==1&&prb5==0){
                                                do{
                                                printf(" congratulations, choose the number from 1 to 4 \n");
                                                printf(" 1 to queen \n 2 to rook \n 3 to eleph \n 4 to knight\n ");
                                                scanf("%d",&prb5);
                                                switch(prb5){
                                                case 1:
                                                    queenprb5_d.x=x*100;queenprb5_d.y=y*100;queenprb5_d.w=100;queenprb5_d.h=100;break;
                                                case 2:
                                                    rookprb5_d.x=x*100;rookprb5_d.y=y*100;rookprb5_d.w=100;rookprb5_d.h=100;break;
                                                case 3:
                                                    elephprb5_d.x=x*100;elephprb5_d.y=y*100;elephprb5_d.w=100;elephprb5_d.h=100;break;
                                                case 4:
                                                    knightprb5_d.x=x*100;knightprb5_d.y=y*100;knightprb5_d.w=100;knightprb5_d.h=100;break;}}
                                                while(prb5!=1&&prb5!=2&&prb5!=3&&prb5!=4);
                                                pawnb5_d=remove_comp(65,pp);}break;}
                                        else if(flag==1&& prb5==1){queenprb5_d.x=x*100;queenprb5_d.y=y*100;queenprb5_d.w=100;queenprb5_d.h=100;break;}
                                        else if(flag==1&& prb5==2){rookprb5_d.x=x*100;rookprb5_d.y=y*100;rookprb5_d.w=100;rookprb5_d.h=100;break;}
                                        else if(flag==1&& prb5==3){elephprb5_d.x=x*100;elephprb5_d.y=y*100;elephprb5_d.w=100;elephprb5_d.h=100;break;}
                                        else if(flag==1&& prb5==4){knightprb5_d.x=x*100;knightprb5_d.y=y*100;knightprb5_d.w=100;knightprb5_d.h=100;break;}
                                        else if(flag==0){textrect7.x=1200;textrect7.y=400;break;}}
                                        else if(t==1){textrect7.x=1200;textrect7.y=400;break;}
                                    case 66:
                                        kill=killed(d,c,y,x,chess_board);
                                        t=check(chess_board,d,c,y,x,kill,pr,pr2,pr3,pr4,pr5,pr6,pr7,pr8,prb,prb2,prb3,prb4,prb5,prb6,prb7,prb8);
                                        if(t==0){
                                          kill=killed(d,c,y,x,chess_board);
                                          if(prb6==0){flag=pawn_moves(kill,d,c,y,x,chess_board);}
                                          else if(prb6==1){flag=queen_moves(d,c,y,x,chess_board,kill);}
                                          else if(prb6==2){flag=rook_moves(d,c,y,x,chess_board,kill);}
                                          else if(prb6==3){flag=bishop_moves(d,c,y,x,chess_board,kill);}
                                          else if(prb6==4){flag=horse_moves(d,c,y,x,chess_board,kill);}
                                        if(flag==1){
                                        textrect7.x=850;textrect7.y=300;
                                        chess_board[y][x]=chess_board[d][c];
                                        chess_board[d][c]=0;
                                        xx=x;yy=y;}
                                        if(kill==1&&flag==1){pp=remove_comp(h,pp);}
                                        if(flag==1 && prb6==0){
                                            pawnb6_d.x=x*100;pawnb6_d.y=y*100;
                                            z=promotion(flag,chess_board,x,y);
                                            if(z==1&&prb6==0){
                                                do{
                                                printf(" congratulations, choose the number from 1 to 4 \n");
                                                printf(" 1 to queen \n 2 to rook \n 3 to eleph \n 4 to knight\n ");
                                                scanf("%d",&prb6);
                                                switch(prb6){
                                                case 1:
                                                    queenprb6_d.x=x*100;queenprb6_d.y=y*100;queenprb6_d.w=100;queenprb6_d.h=100;break;
                                                case 2:
                                                    rookprb6_d.x=x*100;rookprb6_d.y=y*100;rookprb6_d.w=100;rookprb6_d.h=100;break;
                                                case 3:
                                                    elephprb6_d.x=x*100;elephprb6_d.y=y*100;elephprb6_d.w=100;elephprb6_d.h=100;break;
                                                case 4:
                                                    knightprb6_d.x=x*100;knightprb6_d.y=y*100;knightprb6_d.w=100;knightprb6_d.h=100;break;}}
                                                while(prb6!=1&&prb6!=2&&prb6!=3&&prb6!=4);
                                                pawnb6_d=remove_comp(66,pp);}break;}
                                        else if(flag==1&& prb6==1){queenprb6_d.x=x*100;queenprb6_d.y=y*100;queenprb6_d.w=100;queenprb6_d.h=100;break;}
                                        else if(flag==1&& prb6==2){rookprb6_d.x=x*100;rookprb6_d.y=y*100;rookprb6_d.w=100;rookprb6_d.h=100;break;}
                                        else if(flag==1&& prb6==3){elephprb6_d.x=x*100;elephprb6_d.y=y*100;elephprb6_d.w=100;elephprb6_d.h=100;break;}
                                        else if(flag==1&& prb6==4){knightprb6_d.x=x*100;knightprb6_d.y=y*100;knightprb6_d.w=100;knightprb6_d.h=100;break;}
                                        else if(flag==0){textrect7.x=1200;textrect7.y=400;break;}}
                                        else if(t==1){textrect7.x=1200;textrect7.y=400;break;}
                                    case 67:
                                        kill=killed(d,c,y,x,chess_board);
                                        t=check(chess_board,d,c,y,x,kill,pr,pr2,pr3,pr4,pr5,pr6,pr7,pr8,prb,prb2,prb3,prb4,prb5,prb6,prb7,prb8);
                                        if(t==0){
                                          kill=killed(d,c,y,x,chess_board);
                                          if(prb7==0){flag=pawn_moves(kill,d,c,y,x,chess_board);}
                                          else if(prb7==1){flag=queen_moves(d,c,y,x,chess_board,kill);}
                                          else if(prb7==2){flag=rook_moves(d,c,y,x,chess_board,kill);}
                                          else if(prb7==3){flag=bishop_moves(d,c,y,x,chess_board,kill);}
                                          else if(prb7==4){flag=horse_moves(d,c,y,x,chess_board,kill);}
                                         if(flag==1){
                                        textrect7.x=850;textrect7.y=300;
                                        chess_board[y][x]=chess_board[d][c];
                                        chess_board[d][c]=0;
                                        xx=x;yy=y;}
                                        if(kill==1&&flag==1){
                                            pp=remove_comp(h,pp);}
                                        if(flag==1 && prb7==0){
                                            pawnb7_d.x=x*100;pawnb7_d.y=y*100;
                                            z=promotion(flag,chess_board,x,y);
                                            if(z==1&&prb7==0){
                                                do{
                                                printf(" congratulations, choose the number from 1 to 4 \n");
                                                printf(" 1 to queen \n 2 to rook \n 3 to eleph \n 4 to knight\n ");
                                                scanf("%d",&prb7);
                                                switch(prb7){
                                                case 1:
                                                    queenprb7_d.x=x*100;queenprb7_d.y=y*100;queenprb7_d.w=100;queenprb7_d.h=100;break;
                                                case 2:
                                                    rookprb7_d.x=x*100;rookprb7_d.y=y*100;rookprb7_d.w=100;rookprb7_d.h=100;break;
                                                case 3:
                                                    elephprb7_d.x=x*100;elephprb7_d.y=y*100;elephprb7_d.w=100;elephprb7_d.h=100;break;
                                                case 4:
                                                    knightprb7_d.x=x*100;knightprb7_d.y=y*100;knightprb7_d.w=100;knightprb7_d.h=100;break;}}
                                                while(prb7!=1&&prb7!=2&&prb7!=3&&prb7!=4);
                                                pawnb7_d=remove_comp(67,pp);}break;}
                                        else if(flag==1&& prb7==1){queenprb7_d.x=x*100;queenprb7_d.y=y*100;queenprb7_d.w=100;queenprb7_d.h=100;break;}
                                        else if(flag==1&& prb7==2){rookprb7_d.x=x*100;rookprb7_d.y=y*100;rookprb7_d.w=100;rookprb7_d.h=100;break;}
                                        else if(flag==1&& prb7==3){elephprb7_d.x=x*100;elephprb7_d.y=y*100;elephprb7_d.w=100;elephprb7_d.h=100;break;}
                                        else if(flag==1&& prb7==4){knightprb7_d.x=x*100;knightprb7_d.y=y*100;knightprb7_d.w=100;knightprb7_d.h=100;break;}
                                        else if(flag==0){textrect7.x=1200;textrect7.y=400;break;}}
                                        else if(t==1){textrect7.x=1200;textrect7.y=400;break;}
                                    case 68:
                                         kill=killed(d,c,y,x,chess_board);
                                        t=check(chess_board,d,c,y,x,kill,pr,pr2,pr3,pr4,pr5,pr6,pr7,pr8,prb,prb2,prb3,prb4,prb5,prb6,prb7,prb8);
                                        if(t==0){
                                          kill=killed(d,c,y,x,chess_board);
                                          if(prb8==0){flag=pawn_moves(kill,d,c,y,x,chess_board);}
                                          else if(prb8==1){flag=queen_moves(d,c,y,x,chess_board,kill);}
                                          else if(prb8==2){flag=rook_moves(d,c,y,x,chess_board,kill);}
                                          else if(prb8==3){flag=bishop_moves(d,c,y,x,chess_board,kill);}
                                          else if(prb8==4){flag=horse_moves(d,c,y,x,chess_board,kill);}
                                         if(flag==1){
                                        textrect7.x=850;textrect7.y=300;
                                        chess_board[y][x]=chess_board[d][c];
                                        chess_board[d][c]=0;
                                        xx=x;yy=y;}
                                        if(kill==1&&flag==1){pp=remove_comp(h,pp);}
                                        if(flag==1 && prb8==0){
                                            pawnb8_d.x=x*100;pawnb8_d.y=y*100;
                                            z=promotion(flag,chess_board,x,y);
                                            if(z==1&&prb8==0){
                                                do{
                                                printf(" congratulations, choose the number from 1 to 4 \n");
                                                printf(" 1 to queen \n 2 to rook \n 3 to eleph \n 4 to knight\n ");
                                                scanf("%d",&prb8);
                                                switch(prb8){
                                                case 1:
                                                    queenprb8_d.x=x*100;queenprb8_d.y=y*100;queenprb8_d.w=100;queenprb8_d.h=100;break;
                                                case 2:
                                                    rookprb8_d.x=x*100;rookprb8_d.y=y*100;rookprb8_d.w=100;rookprb8_d.h=100;break;
                                                case 3:
                                                    elephprb8_d.x=x*100;elephprb8_d.y=y*100;elephprb8_d.w=100;elephprb8_d.h=100;break;
                                                case 4:
                                                    knightprb8_d.x=x*100;knightprb8_d.y=y*100;knightprb8_d.w=100;knightprb8_d.h=100;break;}}
                                                while(prb8!=1&&prb8!=2&&prb8!=3&&prb8!=4);
                                        pawnb8_d=remove_comp(68,pp);}break;}
                                        else if(flag==1&& prb8==1){queenprb8_d.x=x*100;queenprb8_d.y=y*100;queenprb8_d.w=100;queenprb8_d.h=100;break;}
                                        else if(flag==1&& prb8==2){rookprb8_d.x=x*100;rookprb8_d.y=y*100;rookprb8_d.w=100;rookprb8_d.h=100;break;}
                                        else if(flag==1&& prb8==3){elephprb8_d.x=x*100;elephprb8_d.y=y*100;elephprb8_d.w=100;elephprb8_d.h=100;break;}
                                        else if(flag==1&& prb8==4){knightprb8_d.x=x*100;knightprb8_d.y=y*100;knightprb8_d.w=100;knightprb8_d.h=100;break;}
                                        else if(flag==0){textrect7.x=1200;textrect7.y=400;break;}}
                                        else if(t==1){textrect7.x=1200;textrect7.y=400;break;}
                                    case 71:
                                        kill=killed(d,c,y,x,chess_board);
                                        t=check(chess_board,d,c,y,x,kill,pr,pr2,pr3,pr4,pr5,pr6,pr7,pr8,prb,prb2,prb3,prb4,prb5,prb6,prb7,prb8);
                                        if(t==0){
                                        kill=killed(d,c,y,x,chess_board);
                                        flag=rook_moves(d,c,y,x,chess_board,kill);
                                        if(flag==1){
                                        castrb1=1;
                                        textrect7.x=850;textrect7.y=300;
                                        chess_board[y][x]=chess_board[d][c];
                                        chess_board[d][c]=0;
                                        xx=x;yy=y;}
                                        if(kill==1&&flag==1){pp=remove_comp(h,pp);}
                                        if(flag==1){rookb_d.x=x*100;rookb_d.y=y*100;break;}
                                        else if(flag==0){textrect7.x=1200;textrect7.y=400;break;}}
                                        else if(t==1){textrect7.x=1200;textrect7.y=400;break;}
                                    case 72:
                                        kill=killed(d,c,y,x,chess_board);
                                        t=check(chess_board,d,c,y,x,kill,pr,pr2,pr3,pr4,pr5,pr6,pr7,pr8,prb,prb2,prb3,prb4,prb5,prb6,prb7,prb8);
                                        if(t==0){
                                        kill=killed(d,c,y,x,chess_board);
                                        flag=horse_moves(d,c,y,x,chess_board,kill);
                                        if(flag==1){
                                        textrect7.x=850;textrect7.y=300;
                                        chess_board[y][x]=chess_board[d][c];
                                        chess_board[d][c]=0;
                                        xx=x;yy=y;}
                                        if(kill==1&&flag==1){pp=remove_comp(h,pp);}
                                        if(flag==1){knightb_d.x=x*100;knightb_d.y=y*100;break;}
                                        else if(flag==0){textrect7.x=1200;textrect7.y=400;break;}}
                                        else if(t==1){textrect7.x=1200;textrect7.y=400;break;}
                                    case 73:
                                        kill=killed(d,c,y,x,chess_board);
                                        t=check(chess_board,d,c,y,x,kill,pr,pr2,pr3,pr4,pr5,pr6,pr7,pr8,prb,prb2,prb3,prb4,prb5,prb6,prb7,prb8);
                                        if(t==0){
                                        kill=killed(d,c,y,x,chess_board);
                                        flag=bishop_moves(d,c,y,x,chess_board,kill);
                                        if(flag==1){
                                        textrect7.x=850;textrect7.y=300;
                                        chess_board[y][x]=chess_board[d][c];
                                        chess_board[d][c]=0;
                                        xx=x;yy=y;}
                                        if(kill==1&&flag==1){pp=remove_comp(h,pp);}
                                        if(flag==1){elephb_d.x=x*100;elephb_d.y=y*100;break;}
                                        else if(flag==0){textrect7.x=1200;textrect7.y=400;break;}}
                                        else if(t==1){textrect7.x=1200;textrect7.y=400;break;}
                                    case 74:
                                        kill=killed(d,c,y,x,chess_board);
                                        t=check(chess_board,d,c,y,x,kill,pr,pr2,pr3,pr4,pr5,pr6,pr7,pr8,prb,prb2,prb3,prb4,prb5,prb6,prb7,prb8);
                                        if(t==0){
                                        kill=killed(d,c,y,x,chess_board);
                                        flag=0;
                                    if(((y==d && x==c+1)||(y==d && x==c-1)||(y==d+1 && x==c)||(y==d+1 && x==c+1)||(y==d+1 && x==c-1)||(y==d-1 && x==c)||(y==d-1 && x==c+1)||(y==d-1 && x==c-1))&&((x<8)&&(y<8))){flag=1;}
                                    if((chess_board[d][c]<0) && (chess_board[y][x]<0)){flag=0;}
                                    else if(chess_board[d][c]>0 && chess_board[y][x]>0){flag=0;}
                                        if(flag==1){
                                        t=check(chess_board,d,c,y,x,kill,pr,pr2,pr3,pr4,pr5,pr6,pr7,pr8,prb,prb2,prb3,prb4,prb5,prb6,prb7,prb8);
                                        if(t==1){flag=0;}}
                                        if(y==d && x==c+2 &&chess_board[y][c+1]==0&&chess_board[y][c+2]==0&&castkb==0&&castrb2==0){
                                             checkmate2=checkmate(chess_board,d,c,kill,pr,pr2,pr3,pr4,pr5,pr6,pr7,pr8,prb,prb2,prb3,prb4,prb5,prb6,prb7,prb8);
                                             checkmate3=check(chess_board,d,c,d,c+1,kill,pr,pr2,pr3,pr4,pr5,pr6,pr7,pr8,prb,prb2,prb3,prb4,prb5,prb6,prb7,prb8);
                                             if(checkmate2==0&&checkmate3==0){
                                                kingb_d.x=x*100;kingb_d.y=y*100;
                                                rookb2_d.x=(x-1)*100;rookb2_d.y=y*100;
                                                chess_board[y][x]=chess_board[d][c];
                                                chess_board[d][c]=0;
                                                kb2cc=cc;castkb=1;
                                                chess_board[y][x-1]=chess_board[7][7];
                                                chess_board[7][7]=0;flag=1;}
                                                else(flag=0);}
                                        else if(y==d && x==c-2&&chess_board[y][c-1]==0&&chess_board[y][c-2]==0&&castkb==0&&castrb1==0){
                                            checkmate2=checkmate(chess_board,d,c,kill,pr,pr2,pr3,pr4,pr5,pr6,pr7,pr8,prb,prb2,prb3,prb4,prb5,prb6,prb7,prb8);
                                            checkmate3=check(chess_board,d,c,d,c-1,kill,pr,pr2,pr3,pr4,pr5,pr6,pr7,pr8,prb,prb2,prb3,prb4,prb5,prb6,prb7,prb8);
                                             if(checkmate2==0&&checkmate3==0){
                                                kingb_d.x=x*100;kingb_d.y=y*100;
                                                rookb_d.x=(x+1)*100;rookb_d.y=y*100;
                                                chess_board[y][x]=chess_board[d][c];
                                                chess_board[d][c]=0;
                                                kb1cc=cc;castkb=1;
                                                chess_board[y][x+1]=chess_board[7][0];
                                                chess_board[7][0]=0;flag=1;}
                                                else(flag=0);}
                                        else if(flag==1){
                                        castkb=1;
                                        textrect7.x=850;textrect7.y=300;
                                        chess_board[y][x]=chess_board[d][c];
                                        chess_board[d][c]=0;xx=x;yy=y;}
                                        if(kill==1&&flag==1){pp=remove_comp(h,pp);}
                                        if(flag==1){kingb_d.x=x*100;kingb_d.y=y*100;break;}
                                        else if(flag==0){textrect7.x=1200;textrect7.y=400;break;}}
                                        else if(t==1){textrect7.x=1200;textrect7.y=400;break;}
                                    case 75:
                                        kill=killed(d,c,y,x,chess_board);
                                        t=check(chess_board,d,c,y,x,kill,pr,pr2,pr3,pr4,pr5,pr6,pr7,pr8,prb,prb2,prb3,prb4,prb5,prb6,prb7,prb8);
                                        if(t==0){
                                        kill=killed(d,c,y,x,chess_board);
                                        flag=queen_moves(d,c,y,x,chess_board,kill);
                                        if(flag==1){
                                        textrect7.x=850;textrect7.y=300;
                                        chess_board[y][x]=chess_board[d][c];
                                        chess_board[d][c]=0;
                                        xx=x;yy=y;}
                                        if(kill==1&&flag==1){pp=remove_comp(h,pp);}
                                        if(flag==1){queenb_d.x=x*100;queenb_d.y=y*100;break;}
                                        else if(flag==0){textrect7.x=1200;textrect7.y=400;break;}}
                                        else if(t==1){textrect7.x=1200;textrect7.y=400;break;}
                                    case 76:
                                        kill=killed(d,c,y,x,chess_board);
                                        t=check(chess_board,d,c,y,x,kill,pr,pr2,pr3,pr4,pr5,pr6,pr7,pr8,prb,prb2,prb3,prb4,prb5,prb6,prb7,prb8);
                                        if(t==0){
                                        kill=killed(d,c,y,x,chess_board);
                                        flag=bishop_moves(d,c,y,x,chess_board,kill);
                                        if(flag==1){
                                        textrect7.x=850;textrect7.y=300;
                                        chess_board[y][x]=chess_board[d][c];
                                        chess_board[d][c]=0;
                                        xx=x;yy=y;}
                                        if(kill==1&&flag==1){pp=remove_comp(h,pp);}
                                        if(flag==1){elephb2_d.x=x*100;elephb2_d.y=y*100;break;}
                                        else if(flag==0){textrect7.x=1200;textrect7.y=400;break;}}
                                        else if(t==1){textrect7.x=1200;textrect7.y=400;break;}
                                    case 77:
                                        kill=killed(d,c,y,x,chess_board);
                                        t=check(chess_board,d,c,y,x,kill,pr,pr2,pr3,pr4,pr5,pr6,pr7,pr8,prb,prb2,prb3,prb4,prb5,prb6,prb7,prb8);
                                        if(t==0){
                                        kill=killed(d,c,y,x,chess_board);
                                        flag=horse_moves(d,c,y,x,chess_board,kill);
                                        if(flag==1){
                                        textrect7.x=850;textrect7.y=300;
                                        chess_board[y][x]=chess_board[d][c];
                                        chess_board[d][c]=0;
                                        xx=x;yy=y;}
                                            if(kill==1&&flag==1){pp=remove_comp(h,pp);}
                                            if(flag==1){knightb2_d.x=x*100;knightb2_d.y=y*100;break;}
                                            else if(flag==0){textrect7.x=1200;textrect7.y=400;break;}}
                                        else if(t==1){textrect7.x=1200;textrect7.y=400;break;}
                                    case 78:
                                        kill=killed(d,c,y,x,chess_board);
                                        t=check(chess_board,d,c,y,x,kill,pr,pr2,pr3,pr4,pr5,pr6,pr7,pr8,prb,prb2,prb3,prb4,prb5,prb6,prb7,prb8);
                                        if(t==0){
                                        kill=killed(d,c,y,x,chess_board);
                                        flag=rook_moves(d,c,y,x,chess_board,kill);
                                         if(flag==1){
                                        castrb2=1;
                                        textrect7.x=850;textrect7.y=300;
                                        chess_board[y][x]=chess_board[d][c];
                                        chess_board[d][c]=0;
                                        xx=x;yy=y;}
                                        if(kill==1&&flag==1){pp=remove_comp(h,pp);}
                                        if(flag==1){rookb2_d.x=x*100;rookb2_d.y=y*100;break;}
                                        else if(flag==0){textrect7.x=1200;textrect7.y=400;break;}}
                                        else if(t==1){textrect7.x=1200;textrect7.y=400;break;}}
                            if(flag==1){turn=0;textrect.x=850;textrect.y=400;textrect2.x=850;textrect2.y=300;}
                            if((flag==1)||(t==1))break;}}}
                            if(flag==1){arrpiece[cc]=chess_board[y][x];arrx[cc]=c;arry[cc]=d;arrpr[0][cc]=pr;arrpr[1][cc]=pr2;arrpr[2][cc]=pr3;arrpr[3][cc]=pr4;arrpr[4][cc]=pr5;arrpr[5][cc]=pr6;arrpr[6][cc]=pr7;arrpr[7][cc]=pr8;arrpr[8][cc]=prb;arrpr[9][cc]=prb2;arrpr[10][cc]=prb3;arrpr[11][cc]=prb4;arrpr[12][cc]=prb5;arrpr[13][cc]=prb6,arrpr[14][cc]=prb7;arrpr[15][cc]=prb8;
                          if(kill==1){arrkill[cc]=h;}cc++;zz=1;}a=1;}
                     if((x==c&&y==d&&c==14&&d==3)||(x==c&&y==d&&c==15&&d==3)||(x==c&&y==d&&c==13&&d==3)){
                        for(int i=0;i<8;i++){
                            for(int j=0;j<8;j++){
                                if(chess_board[i][j]==-4){yy=i;xx=j;break;break;}}}}
                    checkmate1=checkmate(chess_board,yy,xx,kill,pr,pr2,pr3,pr4,pr5,pr6,pr7,pr8,prb,prb2,prb3,prb4,prb5,prb6,prb7,prb8);
                    stalemate1=stalemate(chess_board,yy,xx,kill,pr,pr2,pr3,pr4,pr5,pr6,pr7,pr8,prb,prb2,prb3,prb4,prb5,prb6,prb7,prb8);
                    draw1=draw(chess_board);
                    if (flag==1){textrect3.x=850;textrect3.y=300;textrect4.x=850;textrect4.y=300;textrect5.x=850;textrect5.y=300;textrect6.x=850;textrect6.y=300;
                            if(checkmate1==1&&stalemate1==1){textrect3.x=1050;textrect3.y=400;}
                                    else if(draw1==1){textrect.x=850;textrect.y=300;textrect2.x=850;textrect2.y=300;textrect4.x=850;textrect4.y=400;break;}
                                    else if(checkmate1==0 && stalemate1==0){textrect.x=850;textrect.y=300;textrect2.x=850;textrect2.y=300;textrect4.x=850;textrect4.y=400;break;}
                                    else if(checkmate1==1 && stalemate1==0 && h<0){textrect.x=850;textrect.y=300;textrect2.x=850;textrect2.y=300;textrect6.x=850;textrect6.y=400;break;}
                                    else if(checkmate1==1 && stalemate1==0 && h>0){textrect.x=850;textrect.y=300;textrect2.x=850;textrect2.y=300;textrect5.x=850;textrect5.y=400;break;}}}}}
        SDL_SetRenderDrawColor(render,0,0,0,255);
        SDL_RenderClear(render);
        for(int i=0; i<800; i=i+100){
            for(int j=0; j<800; j=j+100){
                if((i%200==0&&j%200==0)||(i%200==100&&j%200==100)){
                    SDL_SetRenderDrawColor(render,255,255,255,255);
                    SDL_Rect rec2;
                    rec2.x=i;rec2.y=j;rec2.w=100;rec2.h=100;
                    SDL_RenderFillRect(render,&rec2);}
                else{
                   SDL_SetRenderDrawColor(render,255,255,255,255);
                    SDL_Rect rec2;
                    rec2.x=i;rec2.y=j+100;rec2.w=100;rec2.h=100;
                    SDL_RenderFillRect(render,&rec2);}}}
        SDL_SetRenderDrawColor(render,255,255,255,255);
        SDL_Rect rec2;
        rec2.x=800;rec2.y=400;rec2.w=800;rec2.h=400;
        SDL_RenderFillRect(render,&rec2);
        if(kill==1&&h==-1&&flag==1&&zz==1){rook_d=pp;}
        SDL_RenderCopy(render,rook_texture,NULL,&rook_d);
        if(kill==1&&h==-8&&flag==1&&zz==1){rook2_d=pp;}
        SDL_RenderCopy(render,rook2_texture,NULL,&rook2_d);
        if(kill==1&&h==71&&flag==1&&zz==1){rookb_d=pp;}
        SDL_RenderCopy(render,rookb_texture,NULL,&rookb_d);
        if(kill==1&&h==78&&flag==1&&zz==1){rookb2_d=pp;}
        SDL_RenderCopy(render,rookb2_texture,NULL,&rookb2_d);
        if(kill==1&&h==-11&&flag==1&&zz==1&&zz==1){
            if(pr==0){pawn_d=pp;}
            else if(pr==1){queenpr_d=pp;pr=0;}
            else if(pr==2){rookpr_d=pp;pr=0;}
            else if(pr==3){elephpr_d=pp;pr=0;}
            else if(pr==4){knightpr_d=pp;pr=0;}}
        SDL_RenderCopy(render,pawn_texture,NULL,&pawn_d);
            if(kill==1&&h==-12&&flag==1&&zz==1){
            if(pr2==0){pawn2_d=pp;}
            else if(pr2==1){queenpr2_d=pp;pr=0;}
            else if(pr2==2){rookpr2_d=pp;pr=0;}
            else if(pr2==3){elephpr2_d=pp;pr=0;}
            else if(pr2==4){knightpr2_d=pp;pr=0;}}
        SDL_RenderCopy(render,pawn2_texture,NULL,&pawn2_d);
            if(kill==1&&h==-13&&flag==1&&zz==1){
            if(pr3==0){pawn3_d=pp;}
            else if(pr3==1){queenpr3_d=pp;pr=0;}
            else if(pr3==2){rookpr3_d=pp;pr=0;}
            else if(pr3==3){elephpr3_d=pp;pr=0;}
            else if(pr3==4){knightpr3_d=pp;pr=0;}}
        SDL_RenderCopy(render,pawn3_texture,NULL,&pawn3_d);
            if(kill==1&&h==-14&&flag==1&&zz==1){
            if(pr4==0){pawn4_d=pp;}
            else if(pr4==1){queenpr4_d=pp;pr=0;}
            else if(pr4==2){rookpr4_d=pp;pr=0;}
            else if(pr4==3){elephpr4_d=pp;pr=0;}
            else if(pr4==4){knightpr4_d=pp;pr=0;}}
        SDL_RenderCopy(render,pawn4_texture,NULL,&pawn4_d);
         if(kill==1&&h==-15&&flag==1&&zz==1){
            if(pr5==0){pawn5_d=pp;}
            else if(pr5==1){queenpr5_d=pp;pr=0;}
            else if(pr5==2){rookpr5_d=pp;pr=0;}
            else if(pr5==3){elephpr5_d=pp;pr=0;}
            else if(pr5==4){knightpr5_d=pp;pr=0;}}
        SDL_RenderCopy(render,pawn5_texture,NULL,&pawn5_d);
         if(kill==1&&h==-16&&flag==1&&zz==1){
            if(pr6==0){pawn6_d=pp;}
            else if(pr6==1){queenpr6_d=pp;pr=0;}
            else if(pr6==2){rookpr6_d=pp;pr=0;}
            else if(pr6==3){elephpr6_d=pp;pr=0;}
            else if(pr6==4){knightpr6_d=pp;pr=0;}}
        SDL_RenderCopy(render,pawn6_texture,NULL,&pawn6_d);
         if(kill==1&&h==-17&&flag==1&&zz==1){
            if(pr7==0){pawn7_d=pp;}
            else if(pr7==1){queenpr7_d=pp;pr=0;}
            else if(pr7==2){rookpr7_d=pp;pr=0;}
            else if(pr7==3){elephpr7_d=pp;pr=0;}
            else if(pr7==4){knightpr7_d=pp;pr=0;}}
        SDL_RenderCopy(render,pawn7_texture,NULL,&pawn7_d);
         if(kill==1&&h==-18&&flag==1&&zz==1){
            if(pr8==0){pawn8_d=pp;}
            else if(pr8==1){queenpr8_d=pp;pr=0;}
            else if(pr8==2){rookpr8_d=pp;pr=0;}
            else if(pr8==3){elephpr8_d=pp;pr=0;}
            else if(pr8==4){knightpr8_d=pp;pr=0;}}
        SDL_RenderCopy(render,pawn8_texture,NULL,&pawn8_d);
         if(kill==1&&h==61&&flag==1&&zz==1){
            if(prb==0){pawnb_d=pp;}
            else if(prb==1){queenprb_d=pp;pr=0;}
            else if(prb==2){rookprb_d=pp;pr=0;}
            else if(prb==3){elephprb_d=pp;pr=0;}
            else if(prb==4){knightprb_d=pp;pr=0;}}
        SDL_RenderCopy(render,pawnb_texture,NULL,&pawnb_d);
         if(kill==1&&h==62&&flag==1&&zz==1){
            if(prb2==0){pawnb2_d=pp;}
            else if(prb2==1){queenprb2_d=pp;pr=0;}
            else if(prb2==2){rookprb2_d=pp;pr=0;}
            else if(prb2==3){elephprb2_d=pp;pr=0;}
            else if(prb2==4){knightprb2_d=pp;pr=0;}}
        SDL_RenderCopy(render,pawnb2_texture,NULL,&pawnb2_d);
         if(kill==1&&h==63&&flag==1&&zz==1){
            if(prb3==0){pawnb3_d=pp;}
            else if(prb3==1){queenprb3_d=pp;pr=0;}
            else if(prb3==2){rookprb3_d=pp;pr=0;}
            else if(prb3==3){elephprb3_d=pp;pr=0;}
            else if(prb3==4){knightprb3_d=pp;pr=0;}}
        SDL_RenderCopy(render,pawnb3_texture,NULL,&pawnb3_d);
         if(kill==1&&h==64&&flag==1&&zz==1){
            if(prb4==0){pawnb4_d=pp;}
            else if(prb4==1){queenprb4_d=pp;pr=0;}
            else if(prb4==2){rookprb4_d=pp;pr=0;}
            else if(prb4==3){elephprb4_d=pp;pr=0;}
            else if(prb4==4){knightprb4_d=pp;pr=0;}}
        SDL_RenderCopy(render,pawnb4_texture,NULL,&pawnb4_d);
         if(kill==1&&h==65&&flag==1&&zz==1){
           if(prb5==0){pawnb5_d=pp;}
            else if(prb5==1){queenprb5_d=pp;pr=0;}
            else if(prb5==2){rookprb5_d=pp;pr=0;}
            else if(prb5==3){elephprb5_d=pp;pr=0;}
            else if(prb5==4){knightprb5_d=pp;pr=0;}}
        SDL_RenderCopy(render,pawnb5_texture,NULL,&pawnb5_d);
         if(kill==1&&h==66&&flag==1&&zz==1){
            if(prb6==0){pawnb6_d=pp;}
            else if(prb6==1){queenprb6_d=pp;pr=0;}
            else if(prb6==2){rookprb6_d=pp;pr=0;}
            else if(prb6==3){elephprb6_d=pp;pr=0;}
            else if(prb6==4){knightprb6_d=pp;pr=0;}}
        SDL_RenderCopy(render,pawnb6_texture,NULL,&pawnb6_d);
         if(kill==1&&h==67&&flag==1&&zz==1){
            if(prb7==0){pawnb7_d=pp;}
            else if(prb7==1){queenprb7_d=pp;pr=0;}
            else if(prb7==2){rookprb7_d=pp;pr=0;}
            else if(prb7==3){elephprb7_d=pp;pr=0;}
            else if(prb7==4){knightprb7_d=pp;pr=0;}}
        SDL_RenderCopy(render,pawnb7_texture,NULL,&pawnb7_d);
         if(kill==1&&h==68&&flag==1&&zz==1){
            if(prb8==0){pawnb8_d=pp;}
            else if(prb8==1){queenprb8_d=pp;pr=0;}
            else if(prb8==2){rookprb8_d=pp;pr=0;}
            else if(prb8==3){elephprb8_d=pp;pr=0;}
            else if(prb8==4){knightprb8_d=pp;pr=0;}}
        SDL_RenderCopy(render,pawnb8_texture,NULL,&pawnb8_d);
         if(kill==1&&h==-3&&flag==1&&zz==1){eleph_d=pp;}
        SDL_RenderCopy(render,eleph_texture,NULL,&eleph_d);
         if(kill==1&&h==-6&&flag==1&&zz==1){eleph2_d=pp;}
        SDL_RenderCopy(render,eleph2_texture,NULL,&eleph2_d);
         if(kill==1&&h==73&&flag==1&&zz==1){elephb_d=pp;}
        SDL_RenderCopy(render,elephb_texture,NULL,&elephb_d);
         if(kill==1&&h==76&&flag==1&&zz==1){elephb2_d=pp;}
        SDL_RenderCopy(render,elephb2_texture,NULL,&elephb2_d);
         if(kill==1&&h==-2&&flag==1&&zz==1){knight_d=pp;}
        SDL_RenderCopy(render,knight_texture,NULL,&knight_d);
         if(kill==1&&h==-7&&flag==1&&zz==1){knight2_d=pp;}
        SDL_RenderCopy(render,knight2_texture,NULL,&knight2_d);
         if(kill==1&&h==72&&flag==1&&zz==1){knightb_d=pp;}
        SDL_RenderCopy(render,knightb_texture,NULL,&knightb_d);
         if(kill==1&&h==77&&flag==1&&zz==1){knightb2_d=pp;}
        SDL_RenderCopy(render,knightb2_texture,NULL,&knightb2_d);
         if(kill==1&&h==-5&&flag==1&&zz==1){queen_d=pp;}
        SDL_RenderCopy(render,queen_texture,NULL,&queen_d);
         if(kill==1&&h==75&&flag==1&&zz==1){queenb_d=pp;}SDL_RenderCopy(render,queenb_texture,NULL,&queenb_d);
         if(kill==1&&h==-4&&flag==1&&zz==1){king_d=pp;}
        SDL_RenderCopy(render,king_texture,NULL,&king_d);
         if(kill==1&&h==74&&flag==1&&zz==1){kingb_d=pp;}
        SDL_RenderCopy(render,kingb_texture,NULL,&kingb_d);
        SDL_RenderCopy(render,queenpr_texture,NULL,&queenpr_d);
        SDL_RenderCopy(render,rookpr_texture,NULL,&rookpr_d);
        SDL_RenderCopy(render,elephpr_texture,NULL,&elephpr_d);
        SDL_RenderCopy(render,knightpr_texture,NULL,&knightpr_d);
        SDL_RenderCopy(render,queenpr2_texture,NULL,&queenpr2_d);
        SDL_RenderCopy(render,rookpr2_texture,NULL,&rookpr2_d);
        SDL_RenderCopy(render,elephpr2_texture,NULL,&elephpr2_d);
        SDL_RenderCopy(render,knightpr2_texture,NULL,&knightpr2_d);
        SDL_RenderCopy(render,queenpr3_texture,NULL,&queenpr3_d);
        SDL_RenderCopy(render,rookpr3_texture,NULL,&rookpr3_d);
        SDL_RenderCopy(render,elephpr3_texture,NULL,&elephpr3_d);
        SDL_RenderCopy(render,knightpr3_texture,NULL,&knightpr3_d);
        SDL_RenderCopy(render,queenpr4_texture,NULL,&queenpr4_d);
        SDL_RenderCopy(render,rookpr4_texture,NULL,&rookpr4_d);
        SDL_RenderCopy(render,elephpr4_texture,NULL,&elephpr4_d);
        SDL_RenderCopy(render,knightpr4_texture,NULL,&knightpr4_d);
        SDL_RenderCopy(render,queenpr5_texture,NULL,&queenpr5_d);
        SDL_RenderCopy(render,rookpr5_texture,NULL,&rookpr5_d);
        SDL_RenderCopy(render,elephpr5_texture,NULL,&elephpr5_d);
        SDL_RenderCopy(render,knightpr5_texture,NULL,&knightpr5_d);
        SDL_RenderCopy(render,queenpr6_texture,NULL,&queenpr6_d);
        SDL_RenderCopy(render,rookpr6_texture,NULL,&rookpr6_d);
        SDL_RenderCopy(render,elephpr6_texture,NULL,&elephpr6_d);
        SDL_RenderCopy(render,knightpr6_texture,NULL,&knightpr6_d);
        SDL_RenderCopy(render,queenpr7_texture,NULL,&queenpr7_d);
        SDL_RenderCopy(render,rookpr7_texture,NULL,&rookpr7_d);
        SDL_RenderCopy(render,elephpr7_texture,NULL,&elephpr7_d);
        SDL_RenderCopy(render,knightpr7_texture,NULL,&knightpr7_d);
        SDL_RenderCopy(render,queenpr8_texture,NULL,&queenpr8_d);
        SDL_RenderCopy(render,rookpr8_texture,NULL,&rookpr8_d);
        SDL_RenderCopy(render,elephpr8_texture,NULL,&elephpr8_d);
        SDL_RenderCopy(render,knightpr8_texture,NULL,&knightpr8_d);
        SDL_RenderCopy(render,queenprb_texture,NULL,&queenprb_d);
        SDL_RenderCopy(render,rookprb_texture,NULL,&rookprb_d);
        SDL_RenderCopy(render,elephprb_texture,NULL,&elephprb_d);
        SDL_RenderCopy(render,knightprb_texture,NULL,&knightprb_d);
        SDL_RenderCopy(render,queenprb2_texture,NULL,&queenprb2_d);
        SDL_RenderCopy(render,rookprb2_texture,NULL,&rookprb2_d);
        SDL_RenderCopy(render,elephprb2_texture,NULL,&elephprb2_d);
        SDL_RenderCopy(render,knightprb2_texture,NULL,&knightprb2_d);
        SDL_RenderCopy(render,queenprb3_texture,NULL,&queenprb3_d);
        SDL_RenderCopy(render,rookprb3_texture,NULL,&rookprb3_d);
        SDL_RenderCopy(render,elephprb3_texture,NULL,&elephprb3_d);
        SDL_RenderCopy(render,knightprb3_texture,NULL,&knightprb3_d);
        SDL_RenderCopy(render,queenprb4_texture,NULL,&queenprb4_d);
        SDL_RenderCopy(render,rookprb4_texture,NULL,&rookprb4_d);
        SDL_RenderCopy(render,elephprb4_texture,NULL,&elephprb4_d);
        SDL_RenderCopy(render,knightprb4_texture,NULL,&knightprb4_d);
        SDL_RenderCopy(render,queenprb5_texture,NULL,&queenprb5_d);
        SDL_RenderCopy(render,rookprb5_texture,NULL,&rookprb5_d);
        SDL_RenderCopy(render,elephprb5_texture,NULL,&elephprb5_d);
        SDL_RenderCopy(render,knightprb5_texture,NULL,&knightprb5_d);
        SDL_RenderCopy(render,queenprb6_texture,NULL,&queenprb6_d);
        SDL_RenderCopy(render,rookprb6_texture,NULL,&rookprb6_d);
        SDL_RenderCopy(render,elephprb6_texture,NULL,&elephprb6_d);
        SDL_RenderCopy(render,knightprb6_texture,NULL,&knightprb6_d);
        SDL_RenderCopy(render,queenprb7_texture,NULL,&queenprb7_d);
        SDL_RenderCopy(render,rookprb7_texture,NULL,&rookprb7_d);
        SDL_RenderCopy(render,elephprb7_texture,NULL,&elephprb7_d);
        SDL_RenderCopy(render,knightprb7_texture,NULL,&knightprb7_d);
        SDL_RenderCopy(render,queenprb8_texture,NULL,&queenprb8_d);
        SDL_RenderCopy(render,rookprb8_texture,NULL,&rookprb8_d);
        SDL_RenderCopy(render,elephprb8_texture,NULL,&elephprb8_d);
        SDL_RenderCopy(render,knightprb8_texture,NULL,&knightprb8_d);
        SDL_RenderCopy(render,save_texture,NULL,&rec3);
        SDL_RenderCopy(render,load_texture,NULL,&rec4);
        SDL_RenderCopy(render,undo_texture,NULL,&rec5);
        SDL_RenderCopy(render,redo_texture,NULL,&rec6);
        SDL_RenderCopy(render,text_texture,NULL,&textrect);
        SDL_RenderCopy(render,text2_texture,NULL,&textrect2);
        SDL_RenderCopy(render,text3_texture,NULL,&textrect3);
        SDL_RenderCopy(render,text4_texture,NULL,&textrect4);
        SDL_RenderCopy(render,text5_texture,NULL,&textrect5);
        SDL_RenderCopy(render,text6_texture,NULL,&textrect6);
        SDL_RenderCopy(render,text7_texture,NULL,&textrect7);
        SDL_RenderPresent(render);}
    SDL_DestroyRenderer(render);
    SDL_DestroyWindow(window);
    SDL_DestroyTexture(text_texture);
    SDL_DestroyTexture(text2_texture);
    SDL_DestroyTexture(text3_texture);
    SDL_DestroyTexture(text4_texture);
    SDL_DestroyTexture(text5_texture);
    SDL_DestroyTexture(text6_texture);
    SDL_DestroyTexture(text7_texture);
    TTF_Quit();
    IMG_Quit();
    SDL_Quit();
    return 0;
}

int pawn_moves(int kill,int w,int l,int y,int x,int chess_board[8][8]){
int flag=0;
if(x<8&&y<8){
    if(chess_board[w][l]<0){
    if(y==w+1 && x==l){
        if(chess_board[y][x]==0){flag=1;}}
    if(w==1){
        if(y==(w+2) && x==l){
            if(chess_board[y][x]==0 && chess_board[w+1][l]==0){flag=1;}}}
     if(y==(w+1) && (x==(l+1)||x==(l-1))){
        if(kill==1){flag=1;}}}
if(chess_board[w][l]>0){
    if(y==w-1 && x==l){
        if(chess_board[y][x]==0){
            flag=1;}}
    if(w==6){
        if(y==(w-2) && x==l){
            if(chess_board[y][x]==0 && chess_board[w-1][l]==0){flag=1;}}}
   if(y==(w-1) && (x==(l+1)||x==(l-1))){
        if(kill==1){flag=1;}}}}
    return flag;}
int horse_moves(int w,int l,int y,int x,int chess_board[8][8],int kill){
int flag=0;
if(x<8&&y<8){
    if((y==w+2 && x==l+1)||(y==w+2 && x==l-1)||(y==w-2 && x==l+1)||(y==w-2 && x==l-1)||(y==w+1 && x==l+2)||(y==w+1 && x==l-2)||(y==w-1 && x==l+2)||(y==w-1 && x==l-2)){
    if(chess_board[w][l]>0 && chess_board[y][x]<0){flag=1;}
    else if(chess_board[w][l]<0 && chess_board[y][x]>0){flag=1;}
    else if(chess_board[y][x]==0){flag=1;}}}
return flag;}
int bishop_moves(int w,int l,int y,int x,int chess_board[8][8],int kill){
int flag=1,i,j;
if(x>7||y>7){flag=0;}
if(abs(w-y)!=abs(l-x)){flag=0;}
else if((l<x)&&(w<y)){
    for(i=l+1,j=w+1;i<x;i++,j++){
        if(chess_board[j][i]!=0){flag=0;break;}}}
else if((l<x)&&(w>y)){
    for(i=l+1,j=w-1;j>y;i++,j--){
        if(chess_board[j][i]!=0){flag=0;break;}}}
else if((l>x)&&(w<y)){
    for(i=l-1,j=w+1;i>x;i--,j++){
        if(chess_board[j][i]!=0){flag=0;break;}}}
else if((l>x)&&(w>y)){
    for(i=l-1,j=w-1;j>y;i--,j--){
        if(chess_board[j][i]!=0){flag=0;break;}}}
if(chess_board[w][l]>0 && chess_board[y][x]>0){flag=0;}
else if(chess_board[w][l]<0 && chess_board[y][x]<0){flag=0;}
return flag;}
int rook_moves(int w,int l,int y,int x,int chess_board[8][8],int kill){
int flag=1,i;
if(x>7||y>7){flag=0;}
if(w==y){
    if((chess_board[w][l]>0) && (chess_board[y][x]>0)){flag=0;}
    else if((chess_board[w][l]<0) && (chess_board[y][x]<0)){flag=0;}
    else{
        for(i=l+1;i<x;i++){
        if(chess_board[y][i]!=0){flag=0;break;}}
    for(i=l-1;i>x;i--){
        if(chess_board[y][i]!=0){flag=0;break;}}}}
else if(l==x){
    if((chess_board[w][l]>0) && (chess_board[y][x]>0)){flag=0;}
    else if((chess_board[w][l]<0) && (chess_board[y][x]<0)){flag=0;}
    else{
        for(i=w+1;i<y;i++){
        if(chess_board[i][x]!=0){flag=0;break;}}
    for(i=w-1;i>y;i--){
        if(chess_board[i][x]!=0){flag=0;break;}}}}
else{flag=0;}return flag;}
int queen_moves(int w,int l,int y,int x,int chess_board[8][8],int kill){
int flag;
if(w==y||l==x){flag=rook_moves(w,l,y,x,chess_board,kill);}
else if(abs(w-y)==abs(l-x)){flag=bishop_moves(w,l,y,x,chess_board,kill);}
else{flag=0;}return flag;}
int promotion (int flag,int chees_board[8][8],int x,int y){
    int z=0;
    if(chees_board[y][x]<0){
        if(y==7){z=1;}}
        else if(chees_board[y][x]>0){
            if(y==0){z=1;}}
    return z;}
SDL_Rect remove_comp(int num,SDL_Rect pp){
switch(num){
        case -1:pp.x=1200;pp.y=0;pp.h=100;pp.w=100;break;
        case -2:pp.x=1300;pp.y=0;pp.h=100;pp.w=100;break;
        case -3:pp.x=1400;pp.y=0;pp.h=100;pp.w=100;break;
        case -4:pp.x=1500;pp.y=0;pp.h=100;pp.w=100;break;
        case -5:pp.x=1200;pp.y=100;pp.h=100;pp.w=100;break;
        case -6:pp.x=1300;pp.y=100;pp.h=100;pp.w=100;break;
        case -7:pp.x=1400;pp.y=100;pp.h=100;pp.w=100;break;
        case -8:pp.x=1500;pp.y=100;pp.h=100;pp.w=100;break;
        case -11:pp.x=1200;pp.y=200;pp.h=100;pp.w=100;break;
        case -12:pp.x=1300;pp.y=200;pp.h=100;pp.w=100;break;
        case -13:pp.x=1400;pp.y=200;pp.h=100;pp.w=100;break;
        case -14:pp.x=1500;pp.y=200;pp.h=100;pp.w=100;break;
        case -15:pp.x=800;pp.y=0;pp.h=100;pp.w=100;break;
        case -16:pp.x=900;pp.y=00;pp.h=100;pp.w=100;break;
        case -17:pp.x=1000;pp.y=0;pp.h=100;pp.w=100;break;
        case -18:pp.x=1100;pp.y=0;pp.h=100;pp.w=100;break;
        case 61:pp.x=800;pp.y=700;pp.h=100;pp.w=100;break;
        case 62:pp.x=900;pp.y=700;pp.h=100;pp.w=100;break;
        case 63:pp.x=1000;pp.y=700;pp.h=100;pp.w=100;break;
        case 64:pp.x=1100;pp.y=700;pp.h=100;pp.w=100;break;
        case 65:pp.x=1200;pp.y=700;pp.h=100;pp.w=100;break;
        case 66:pp.x=1300;pp.y=700;pp.h=100;pp.w=100;break;
        case 67:pp.x=1400;pp.y=700;pp.h=100;pp.w=100;break;
        case 68:pp.x=1500;pp.y=700;pp.h=100;pp.w=100;break;
        case 71:pp.x=800;pp.y=600;pp.h=100;pp.w=100;break;
        case 72:pp.x=900;pp.y=600;pp.h=100;pp.w=100;break;
        case 73:pp.x=1000;pp.y=600;pp.h=100;pp.w=100;break;
        case 74:pp.x=1100;pp.y=600;pp.h=100;pp.w=100;break;
        case 75:pp.x=1200;pp.y=600;pp.h=100;pp.w=100;break;
        case 76:pp.x=1300;pp.y=600;pp.h=100;pp.w=100;break;
        case 77:pp.x=1400;pp.y=600;pp.h=100;pp.w=100;break;
        case 78:pp.x=1500;pp.y=600;pp.h=100;pp.w=100;break;
    }return pp;}
int check(int chess_board[8][8],int w,int l,int y1,int x1,int kill,int pr,int pr2,int pr3,int pr4,int pr5,int pr6,int pr7,int pr8,int prb,int prb2,int prb3,int prb4,int prb5,int prb6,int prb7,int prb8){
	  int t=0,i,j,y,x,h;
	  h=chess_board[y1][x1];
	  chess_board[y1][x1]=chess_board[w][l];
	  chess_board[w][l]=0;
	  if(w==y1&&l==x1){chess_board[w][l]=h;}
	   if(chess_board[y1][x1]<0){
	     for(i=0;i<=7;i++){
		 for(j=0;j<=7;j++){
			if(chess_board[i][j]==-4){y=i; x=j;break;}}}
        for(i=0;i<=7;i++){if (t==1){break;}
        for(j=0;j<=7;j++){
	 if(chess_board[i][j]==61){
        if(prb==0){t=pawn_moves(kill=1,i,j,y,x,chess_board);}
        else if(prb==1){t=queen_moves(i,j,y,x,chess_board,kill);}
        else if(prb==2){t=rook_moves(i,j,y,x,chess_board,kill);}
        else if(prb==3){t=bishop_moves(i,j,y,x,chess_board,kill);}
        else if(prb==4){t=horse_moves(i,j,y,x,chess_board,kill);}}
	 else if(chess_board[i][j]==62){
        if(prb2==0){t=pawn_moves(kill=1,i,j,y,x,chess_board);}
        else if(prb2==1){t=queen_moves(i,j,y,x,chess_board,kill);}
        else if(prb2==2){t=rook_moves(i,j,y,x,chess_board,kill);}
        else if(prb2==3){t=bishop_moves(i,j,y,x,chess_board,kill);}
        else if(prb2==4){t=horse_moves(i,j,y,x,chess_board,kill);}}
	 else if(chess_board[i][j]==63){
        if(prb3==0){t=pawn_moves(kill=1,i,j,y,x,chess_board);}
        else if(prb3==1){t=queen_moves(i,j,y,x,chess_board,kill);}
        else if(prb3==2){t=rook_moves(i,j,y,x,chess_board,kill);}
        else if(prb3==3){t=bishop_moves(i,j,y,x,chess_board,kill);}
        else if(prb3==4){t=horse_moves(i,j,y,x,chess_board,kill);}}
	 else if(chess_board[i][j]==64){
        if(prb4==0){t=pawn_moves(kill=1,i,j,y,x,chess_board);}
        else if(prb4==1){t=queen_moves(i,j,y,x,chess_board,kill);}
        else if(prb4==2){t=rook_moves(i,j,y,x,chess_board,kill);}
        else if(prb4==3){t=bishop_moves(i,j,y,x,chess_board,kill);}
        else if(prb4==4){t=horse_moves(i,j,y,x,chess_board,kill);}}
	 else if(chess_board[i][j]==65){
        if(prb5==0){t=pawn_moves(kill=1,i,j,y,x,chess_board);}
        else if(prb5==1){t=queen_moves(i,j,y,x,chess_board,kill);}
        else if(prb5==2){t=rook_moves(i,j,y,x,chess_board,kill);}
        else if(prb5==3){t=bishop_moves(i,j,y,x,chess_board,kill);}
        else if(prb5==4){t=horse_moves(i,j,y,x,chess_board,kill);}}
	 else if(chess_board[i][j]==66){
        if(prb6==0){t=pawn_moves(kill=1,i,j,y,x,chess_board);}
        else if(prb6==1){t=queen_moves(i,j,y,x,chess_board,kill);}
        else if(prb6==2){t=rook_moves(i,j,y,x,chess_board,kill);}
        else if(prb6==3){t=bishop_moves(i,j,y,x,chess_board,kill);}
        else if(prb6==4){t=horse_moves(i,j,y,x,chess_board,kill);}}
	 else if(chess_board[i][j]==67){
        if(prb7==0){t=pawn_moves(kill=1,i,j,y,x,chess_board);}
        else if(prb7==1){t=queen_moves(i,j,y,x,chess_board,kill);}
        else if(prb7==2){t=rook_moves(i,j,y,x,chess_board,kill);}
        else if(prb7==3){t=bishop_moves(i,j,y,x,chess_board,kill);}
        else if(prb7==4){t=horse_moves(i,j,y,x,chess_board,kill);}}
	 else if(chess_board[i][j]==68){
        if(prb8==0){t=pawn_moves(kill=1,i,j,y,x,chess_board);}
        else if(prb8==1){t=queen_moves(i,j,y,x,chess_board,kill);}
        else if(prb8==2){t=rook_moves(i,j,y,x,chess_board,kill);}
        else if(prb8==3){t=bishop_moves(i,j,y,x,chess_board,kill);}
        else if(prb8==4){t=horse_moves(i,j,y,x,chess_board,kill);}}
	 else if(chess_board[i][j]==72 || chess_board[i][j]==77)t = horse_moves(i,j,y,x,chess_board,kill);
	 else if(chess_board[i][j]==75)t = queen_moves(i,j,y,x,chess_board,kill);
	 else if(chess_board[i][j]==71 || chess_board[i][j]==78)t = rook_moves(i,j,y,x,chess_board,kill);
	 else if(chess_board[i][j]==73 || chess_board[i][j]==76)t = bishop_moves(i,j,y,x,chess_board,kill);
	 else if(chess_board[i][j]==74){t=0;
        if(((y==i && x==j+1)||(y==i && x==j-1)||(y==i+1 && x==j)||(y==i+1 && x==j+1)||(y==i+1 && x==j-1)||(y==i-1 && x==j)||(y==i-1 && x==j+1)||(y==i-1 && x==j-1))&&((x<8)&&(y<8))){t=1;}
        if((chess_board[i][j]<0) && (chess_board[y][x]<0)){t=0;}
        else if(chess_board[i][j]>0 && chess_board[y][x]>0){t=0;}}
        if (t==1){break;}}}}
if(chess_board[y1][x1]>0){
	     for(i=0;i<=7;i++){
		 for(j=0;j<=7;j++){
			if(chess_board[i][j]==74){y=i; x=j;break;}}}
        for(i=0;i<=7;i++){
                if (t==1){break;}
        for(j=0;j<=7;j++){
	 if(chess_board[i][j]==-11){
        if(pr==0){t=pawn_moves(kill=1,i,j,y,x,chess_board);}
        else if(pr==1){t=queen_moves(i,j,y,x,chess_board,kill);}
        else if(pr==2){t=rook_moves(i,j,y,x,chess_board,kill);}
        else if(pr==3){t=bishop_moves(i,j,y,x,chess_board,kill);}
        else if(pr==4){t=horse_moves(i,j,y,x,chess_board,kill);}}
	 else if(chess_board[i][j]==-12){
        if(pr2==0){t=pawn_moves(kill=1,i,j,y,x,chess_board);}
        else if(pr2==1){t=queen_moves(i,j,y,x,chess_board,kill);}
        else if(pr2==2){t=rook_moves(i,j,y,x,chess_board,kill);}
        else if(pr2==3){t=bishop_moves(i,j,y,x,chess_board,kill);}
        else if(pr2==4){t=horse_moves(i,j,y,x,chess_board,kill);}}
	 else if(chess_board[i][j]==-13){
        if(pr3==0){t=pawn_moves(kill=1,i,j,y,x,chess_board);}
        else if(pr3==1){t=queen_moves(i,j,y,x,chess_board,kill);}
        else if(pr3==2){t=rook_moves(i,j,y,x,chess_board,kill);}
        else if(pr3==3){t=bishop_moves(i,j,y,x,chess_board,kill);}
        else if(pr3==4){t=horse_moves(i,j,y,x,chess_board,kill);}}
	 else if(chess_board[i][j]==-14){
        if(pr4==0){t=pawn_moves(kill=1,i,j,y,x,chess_board);}
        else if(pr4==1){t=queen_moves(i,j,y,x,chess_board,kill);}
        else if(pr4==2){t=rook_moves(i,j,y,x,chess_board,kill);}
        else if(pr4==3){t=bishop_moves(i,j,y,x,chess_board,kill);}
        else if(pr4==4){t=horse_moves(i,j,y,x,chess_board,kill);}}
	 else if(chess_board[i][j]==-15){
        if(pr5==0){t=pawn_moves(kill=1,i,j,y,x,chess_board);}
        else if(pr5==1){t=queen_moves(i,j,y,x,chess_board,kill);}
        else if(pr5==2){t=rook_moves(i,j,y,x,chess_board,kill);}
        else if(pr5==3){t=bishop_moves(i,j,y,x,chess_board,kill);}
        else if(pr5==4){t=horse_moves(i,j,y,x,chess_board,kill);}}
	 else if(chess_board[i][j]==-16){
        if(pr6==0){t=pawn_moves(kill=1,i,j,y,x,chess_board);}
        else if(pr6==1){t=queen_moves(i,j,y,x,chess_board,kill);}
        else if(pr6==2){t=rook_moves(i,j,y,x,chess_board,kill);}
        else if(pr6==3){t=bishop_moves(i,j,y,x,chess_board,kill);}
        else if(pr6==4){t=horse_moves(i,j,y,x,chess_board,kill);}}
	 else if(chess_board[i][j]==-17){
        if(pr7==0){t=pawn_moves(kill=1,i,j,y,x,chess_board);}
        else if(pr7==1){t=queen_moves(i,j,y,x,chess_board,kill);}
        else if(pr7==2){t=rook_moves(i,j,y,x,chess_board,kill);}
        else if(pr7==3){t=bishop_moves(i,j,y,x,chess_board,kill);}
        else if(pr7==4){t=horse_moves(i,j,y,x,chess_board,kill);}}
	 else if(chess_board[i][j]==-18){
        if(pr8==0){t=pawn_moves(kill=1,i,j,y,x,chess_board);}
        else if(pr8==1){t=queen_moves(i,j,y,x,chess_board,kill);}
        else if(pr8==2){t=rook_moves(i,j,y,x,chess_board,kill);}
        else if(pr8==3){t=bishop_moves(i,j,y,x,chess_board,kill);}
        else if(pr8==4){t=horse_moves(i,j,y,x,chess_board,kill);}}
	 else if(chess_board[i][j]==(-2) || chess_board[i][j]==(-7))t = horse_moves(i,j,y,x,chess_board,kill);
	 else if(chess_board[i][j]==(-5))t = queen_moves(i,j,y,x,chess_board,kill);
	 else if(chess_board[i][j]==(-1) || chess_board[i][j]==(-8))t = rook_moves(i,j,y,x,chess_board,kill);
	 else if(chess_board[i][j]==(-3) || chess_board[i][j]==(-6))t = bishop_moves(i,j,y,x,chess_board,kill);
	 else if(chess_board[i][j]==(-4)){t=0;
        if(((y==i && x==j+1)||(y==i && x==j-1)||(y==i+1 && x==j)||(y==i+1 && x==j+1)||(y==i+1 && x==j-1)||(y==i-1 && x==j)||(y==i-1 && x==j+1)||(y==i-1 && x==j-1))&&((x<8)&&(y<8))){t=1;}
        if((chess_board[i][j]<0) && (chess_board[y][x]<0)){t=0;}
        else if(chess_board[i][j]>0 && chess_board[y][x]>0){t=0;}}
        if (t==1){break;}}}}
chess_board[w][l]=chess_board[y1][x1];
chess_board[y1][x1]=h;
return t;}
int checkmate(int chess_board[8][8],int y,int x,int kill,int pr,int pr2,int pr3,int pr4,int pr5,int pr6,int pr7,int pr8,int prb,int prb2,int prb3,int prb4,int prb5,int prb6,int prb7,int prb8){
int a,b,i,j,f;
if(chess_board[y][x]>0){
	     for(i=0;i<=7;i++){
		 for(j=0;j<=7;j++){
			if(chess_board[i][j]==-4){a=i;b=j;break;}}}}
if(chess_board[y][x]<0){
	     for(i=0;i<=7;i++){
		 for(j=0;j<=7;j++){
			if(chess_board[i][j]==74){a=i;b=j;break;}}}}
    f=check(chess_board,a,b,a,b,kill,pr,pr2,pr3,pr4,pr5,pr6,pr7,pr8,prb,prb2,prb3,prb4,prb5,prb6,prb7,prb8);
return f;}
int killed(int w,int l,int y,int x,int chess_board[8][8]){
int kill=0;
if(((chess_board[w][l]>0) && (chess_board[y][x]<0)) || ((chess_board[w][l]<0) && (chess_board[y][x]>0))){kill=1;}return kill;}
int draw(int chess_board[8][8]){
    int k=0,i,j,f=0,t;
    int rest_pieces[4]={0};
    for(i=0;i<=7;i++){
            if(k==5){break;}
		 for(j=0;j<=7;j++){
			if(chess_board[i][j]!=0){
                    rest_pieces[k]=chess_board[i][j];k++;
                    if(k==5){break;}}}}
    for(i=0; i<5; i++){
        for(j=i+1; j<5; j++){
            if(rest_pieces[j] < rest_pieces[i]){
                t = rest_pieces[i];
                rest_pieces[i] = rest_pieces[j];
                rest_pieces[j] = t;}}}
    if((rest_pieces[0]==(-4)) && (rest_pieces[3]==74) && (rest_pieces[1]==0) && (rest_pieces[2]==0)){f=1;}
    if((rest_pieces[0]==(-4) && rest_pieces[1]==(-3) && rest_pieces[2]==0 && rest_pieces[3]==74) || (rest_pieces[0]==(-6) && rest_pieces[1]==(-4) && rest_pieces[2]==0 && rest_pieces[3]==74) || (rest_pieces[0]==(-4) && rest_pieces[1]==0 && rest_pieces[2]==73 && rest_pieces[3]==74) || (rest_pieces[0]==(-4) && rest_pieces[1]==0 && rest_pieces[2]==74 && rest_pieces[3]==76)){f=1;}
    if((rest_pieces[0]==(-4) && rest_pieces[1]==(-2) && rest_pieces[2]==0 && rest_pieces[3]==74) || (rest_pieces[0]==(-7) && rest_pieces[1]==(-4) && rest_pieces[2]==0 && rest_pieces[3]==74) || (rest_pieces[0]==(-4) && rest_pieces[1]==0 && rest_pieces[2]==72 && rest_pieces[3]==74) || (rest_pieces[0]==(-4) && rest_pieces[1]==0 && rest_pieces[2]==74 && rest_pieces[3]==77)){f=1;}
    if((rest_pieces[0]==(-4) && rest_pieces[1]==(-3) && rest_pieces[2]==74 && rest_pieces[3]==76) || (rest_pieces[0]==(-6) && rest_pieces[1]==(-4) && rest_pieces[2]==73 && rest_pieces[3]==74)){f=1;}
    return f;}
int stalemate(int chess_board[8][8],int y,int x,int kill,int pr,int pr2,int pr3,int pr4,int pr5,int pr6,int pr7,int pr8,int prb,int prb2,int prb3,int prb4,int prb5,int prb6,int prb7,int prb8){
	  int t=0,i,j,k,p,h;
	   if(chess_board[y][x]<0){
    for(i=0;i<=7;i++){
            if (t==1){break;}
        for(j=0;j<=7;j++){
 if(chess_board[i][j]==61){
        for(k=0;k<=7;k++){
                if (t==1){break;}
                for(p=0;p<=7;p++){
                    if(prb==0){t=pawn_moves(kill=0,i,j,k,p,chess_board);}
                    if (t==1){h=check(chess_board,i,j,k,p,kill,pr,pr2,pr3,pr4,pr5,pr6,pr7,pr8,prb,prb2,prb3,prb4,prb5,prb6,prb7,prb8);
                        if(h==1){t=0;}
                        else if(h==0){break;}}
        if(prb==0){t=pawn_moves(kill=1,i,j,k,p,chess_board);}
        else if(prb==1){t=queen_moves(i,j,k,p,chess_board,kill);}
        else if(prb==2){t=rook_moves(i,j,k,p,chess_board,kill);}
        else if(prb==3){t=bishop_moves(i,j,k,p,chess_board,kill);}
        else if(prb==4){t=horse_moves(i,j,k,p,chess_board,kill);}
        if (t==1){h=check(chess_board,i,j,k,p,kill,pr,pr2,pr3,pr4,pr5,pr6,pr7,pr8,prb,prb2,prb3,prb4,prb5,prb6,prb7,prb8);
                        if(h==1){t=0;}
                        else if(h==0){break;}}}}}
	 else if(chess_board[i][j]==62){
        for(k=0;k<=7;k++){
                if (t==1){break;}
                for(p=0;p<=7;p++){
                    if(prb2==0){t = pawn_moves(kill=0,i,j,k,p,chess_board);}
                    if (t==1){h=check(chess_board,i,j,k,p,kill,pr,pr2,pr3,pr4,pr5,pr6,pr7,pr8,prb,prb2,prb3,prb4,prb5,prb6,prb7,prb8);
                        if(h==1){t=0;}
                        else if(h==0){break;}}
        if(prb2==0){t=pawn_moves(kill=1,i,j,k,p,chess_board);}
        else if(prb2==1){t=queen_moves(i,j,k,p,chess_board,kill);}
        else if(prb2==2){t=rook_moves(i,j,k,p,chess_board,kill);}
        else if(prb2==3){t=bishop_moves(i,j,k,p,chess_board,kill);}
        else if(prb2==4){t=horse_moves(i,j,k,p,chess_board,kill);}
        if (t==1){h=check(chess_board,i,j,k,p,kill,pr,pr2,pr3,pr4,pr5,pr6,pr7,pr8,prb,prb2,prb3,prb4,prb5,prb6,prb7,prb8);
                        if(h==1){t=0;}
                        else if(h==0){break;}}}}}
	 else if(chess_board[i][j]==63){
        for(k=0;k<=7;k++){
                if (t==1){break;}
                for(p=0;p<=7;p++){
                    if(prb3==0){t = pawn_moves(kill=0,i,j,k,p,chess_board);}
                    if (t==1){h=check(chess_board,i,j,k,p,kill,pr,pr2,pr3,pr4,pr5,pr6,pr7,pr8,prb,prb2,prb3,prb4,prb5,prb6,prb7,prb8);
                        if(h==1){t=0;}
                        else if(h==0){break;}}
        if(prb3==0){t=pawn_moves(kill=1,i,j,k,p,chess_board);}
        else if(prb3==1){t=queen_moves(i,j,k,p,chess_board,kill);}
        else if(prb3==2){t=rook_moves(i,j,k,p,chess_board,kill);}
        else if(prb3==3){t=bishop_moves(i,j,k,p,chess_board,kill);}
        else if(prb3==4){t=horse_moves(i,j,k,p,chess_board,kill);}
        if (t==1){h=check(chess_board,i,j,k,p,kill,pr,pr2,pr3,pr4,pr5,pr6,pr7,pr8,prb,prb2,prb3,prb4,prb5,prb6,prb7,prb8);
                        if(h==1){t=0;}
                        else if(h==0){break;}}}}}
	 else if(chess_board[i][j]==64){
               for(k=0;k<=7;k++){
                if (t==1){break;}
                for(p=0;p<=7;p++){
                    if(prb4==0){t = pawn_moves(kill=0,i,j,k,p,chess_board);}
                    if (t==1){h=check(chess_board,i,j,k,p,kill,pr,pr2,pr3,pr4,pr5,pr6,pr7,pr8,prb,prb2,prb3,prb4,prb5,prb6,prb7,prb8);
                        if(h==1){t=0;}
                        else if(h==0){break;}}
        if(prb4==0){t=pawn_moves(kill=1,i,j,k,p,chess_board);}
        else if(prb4==1){t=queen_moves(i,j,k,p,chess_board,kill);}
        else if(prb4==2){t=rook_moves(i,j,k,p,chess_board,kill);}
        else if(prb4==3){t=bishop_moves(i,j,k,p,chess_board,kill);}
        else if(prb4==4){t=horse_moves(i,j,k,p,chess_board,kill);}
        if (t==1){h=check(chess_board,i,j,k,p,kill,pr,pr2,pr3,pr4,pr5,pr6,pr7,pr8,prb,prb2,prb3,prb4,prb5,prb6,prb7,prb8);
                        if(h==1){t=0;}
                        else if(h==0){break;}}}}}
	 else if(chess_board[i][j]==65){
                for(k=0;k<=7;k++){
                if (t==1){break;}
                for(p=0;p<=7;p++){
                    if(prb5==0){t = pawn_moves(kill=0,i,j,k,p,chess_board);}
                    if (t==1){h=check(chess_board,i,j,k,p,kill,pr,pr2,pr3,pr4,pr5,pr6,pr7,pr8,prb,prb2,prb3,prb4,prb5,prb6,prb7,prb8);
                        if(h==1){t=0;}
                        else if(h==0){break;}}
        if(prb5==0){t=pawn_moves(kill=1,i,j,k,p,chess_board);}
        else if(prb5==1){t=queen_moves(i,j,k,p,chess_board,kill);}
        else if(prb5==2){t=rook_moves(i,j,k,p,chess_board,kill);}
        else if(prb5==3){t=bishop_moves(i,j,k,p,chess_board,kill);}
        else if(prb5==4){t=horse_moves(i,j,k,p,chess_board,kill);}
        if (t==1){h=check(chess_board,i,j,k,p,kill,pr,pr2,pr3,pr4,pr5,pr6,pr7,pr8,prb,prb2,prb3,prb4,prb5,prb6,prb7,prb8);
                        if(h==1){t=0;}
                        else if(h==0){break;}}}}}
	 else if(chess_board[i][j]==66){
                for(k=0;k<=7;k++){
                if (t==1){break;}
                for(p=0;p<=7;p++){
                    if(prb6==0){t = pawn_moves(kill=0,i,j,k,p,chess_board);}
                    if (t==1){h=check(chess_board,i,j,k,p,kill,pr,pr2,pr3,pr4,pr5,pr6,pr7,pr8,prb,prb2,prb3,prb4,prb5,prb6,prb7,prb8);
                        if(h==1){t=0;}
                        else if(h==0){break;}}
        if(prb6==0){t=pawn_moves(kill=1,i,j,k,p,chess_board);}
        else if(prb6==1){t=queen_moves(i,j,k,p,chess_board,kill);}
        else if(prb6==2){t=rook_moves(i,j,k,p,chess_board,kill);}
        else if(prb6==3){t=bishop_moves(i,j,k,p,chess_board,kill);}
        else if(prb6==4){t=horse_moves(i,j,k,p,chess_board,kill);}
        if (t==1){h=check(chess_board,i,j,k,p,kill,pr,pr2,pr3,pr4,pr5,pr6,pr7,pr8,prb,prb2,prb3,prb4,prb5,prb6,prb7,prb8);
                        if(h==1){t=0;}
                        else if(h==0){break;}}}}}
	 else if(chess_board[i][j]==67){
            for(k=0;k<=7;k++){
                if (t==1){break;}
                for(p=0;p<=7;p++){
                    if(prb7==0){t = pawn_moves(kill=0,i,j,k,p,chess_board);}
                    if (t==1){h=check(chess_board,i,j,k,p,kill,pr,pr2,pr3,pr4,pr5,pr6,pr7,pr8,prb,prb2,prb3,prb4,prb5,prb6,prb7,prb8);
                        if(h==1){t=0;}
                        else if(h==0){break;}}
        if(prb7==0){t=pawn_moves(kill=1,i,j,k,p,chess_board);}
        else if(prb7==1){t=queen_moves(i,j,k,p,chess_board,kill);}
        else if(prb7==2){t=rook_moves(i,j,k,p,chess_board,kill);}
        else if(prb7==3){t=bishop_moves(i,j,k,p,chess_board,kill);}
        else if(prb7==4){t=horse_moves(i,j,k,p,chess_board,kill);}
        if (t==1){h=check(chess_board,i,j,k,p,kill,pr,pr2,pr3,pr4,pr5,pr6,pr7,pr8,prb,prb2,prb3,prb4,prb5,prb6,prb7,prb8);
                        if(h==1){t=0;}
                        else if(h==0){break;}}}}}
	 else if(chess_board[i][j]==68){
            for(k=0;k<=7;k++){
                if (t==1){break;}
                for(p=0;p<=7;p++){
                    if(prb8==0){t = pawn_moves(kill=0,i,j,k,p,chess_board);}
                    if (t==1){h=check(chess_board,i,j,k,p,kill,pr,pr2,pr3,pr4,pr5,pr6,pr7,pr8,prb,prb2,prb3,prb4,prb5,prb6,prb7,prb8);
                        if(h==1){t=0;}
                        else if(h==0){break;}}
        if(prb8==0){t=pawn_moves(kill=1,i,j,k,p,chess_board);}
        else if(prb8==1){t=queen_moves(i,j,k,p,chess_board,kill);}
        else if(prb8==2){t=rook_moves(i,j,k,p,chess_board,kill);}
        else if(prb8==3){t=bishop_moves(i,j,k,p,chess_board,kill);}
        else if(prb8==4){t=horse_moves(i,j,k,p,chess_board,kill);}
        if (t==1){h=check(chess_board,i,j,k,p,kill,pr,pr2,pr3,pr4,pr5,pr6,pr7,pr8,prb,prb2,prb3,prb4,prb5,prb6,prb7,prb8);
                        if(h==1){t=0;}
                        else if(h==0){break;}}}}}
	 else if(chess_board[i][j]==72 || chess_board[i][j]==77){
            for(k=0;k<=7;k++){
                if (t==1){break;}
                for(p=0;p<=7;p++){t = horse_moves(i,j,k,p,chess_board,kill);
                    if (t==1){h=check(chess_board,i,j,k,p,kill,pr,pr2,pr3,pr4,pr5,pr6,pr7,pr8,prb,prb2,prb3,prb4,prb5,prb6,prb7,prb8);
                        if(h==1){t=0;}
                        else if(h==0){break;}}}}}
	 else if(chess_board[i][j]==75){
            for(k=0;k<=7;k++){
                if (t==1){break;}
                for(p=0;p<=7;p++){t = queen_moves(i,j,k,p,chess_board,kill);
                    if (t==1){h=check(chess_board,i,j,k,p,kill,pr,pr2,pr3,pr4,pr5,pr6,pr7,pr8,prb,prb2,prb3,prb4,prb5,prb6,prb7,prb8);
                        if(h==1){t=0;}
                        else if(h==0){break;}}}}}
	 else if(chess_board[i][j]==71 || chess_board[i][j]==78){
            for(k=0;k<=7;k++){
                if (t==1){break;}
                for(p=0;p<=7;p++){t = rook_moves(i,j,k,p,chess_board,kill);
                    if (t==1){h=check(chess_board,i,j,k,p,kill,pr,pr2,pr3,pr4,pr5,pr6,pr7,pr8,prb,prb2,prb3,prb4,prb5,prb6,prb7,prb8);
                        if(h==1){t=0;}
                        else if(h==0){break;}}}}}
	 else if(chess_board[i][j]==73 || chess_board[i][j]==76){
            for(k=0;k<=7;k++){
                if (t==1){break;}
                for(p=0;p<=7;p++){t = bishop_moves(i,j,k,p,chess_board,kill);
                    if (t==1){h=check(chess_board,i,j,k,p,kill,pr,pr2,pr3,pr4,pr5,pr6,pr7,pr8,prb,prb2,prb3,prb4,prb5,prb6,prb7,prb8);
                        if(h==1){t=0;}
                        else if(h==0){
                         break;}}}}}
	 else if(chess_board[i][j]==74){
      for(k=0;k<=7;k++){
                if (t==1){break;}
                for(p=0;p<=7;p++){t=0;
                    if(((k==i && p==j+1)||(k==i && p==j-1)||(k==i+1 && p==j)||(k==i+1 && p==j+1)||(k==i+1 && p==j-1)||(k==i-1 && p==j)||(k==i-1 && p==j+1)||(k==i-1 && p==j-1))&&((p<8)&&(k<8))){t=1;}
                    if((chess_board[i][j]<0) && (chess_board[k][p]<0)){t=0;}
                    else if(chess_board[i][j]>0 && chess_board[k][p]>0){t=0;}
                    if (t==1){h=check(chess_board,i,j,k,p,kill,pr,pr2,pr3,pr4,pr5,pr6,pr7,pr8,prb,prb2,prb3,prb4,prb5,prb6,prb7,prb8);
                        if(h==1){t=0;}
                        else if(h==0){break;}}}}}
    if (t==1){break;}}}}
if(chess_board[y][x]>0){
    for(i=0;i<=7;i++){
            if (t==1){break;}
        for(j=0;j<=7;j++){
        if(chess_board[i][j]==(-11)){
            for(k=0;k<=7;k++){
                if (t==1){break;}
                for(p=0;p<=7;p++){
                    if(pr==0){t = pawn_moves(kill=0,i,j,k,p,chess_board);}
                    if (t==1){h=check(chess_board,i,j,k,p,kill,pr,pr2,pr3,pr4,pr5,pr6,pr7,pr8,prb,prb2,prb3,prb4,prb5,prb6,prb7,prb8);
                        if(h==1){t=0;}
                        else if(h==0){break;}}
        if(pr==0){t=pawn_moves(kill=1,i,j,k,p,chess_board);}
        else if(pr==1){t=queen_moves(i,j,k,p,chess_board,kill);}
        else if(pr==2){t=rook_moves(i,j,k,p,chess_board,kill);}
        else if(pr==3){t=bishop_moves(i,j,k,p,chess_board,kill);}
        else if(pr==4){t=horse_moves(i,j,k,p,chess_board,kill);}
        if (t==1){h=check(chess_board,i,j,k,p,kill,pr,pr2,pr3,pr4,pr5,pr6,pr7,pr8,prb,prb2,prb3,prb4,prb5,prb6,prb7,prb8);
                        if(h==1){t=0;}
                        else if(h==0){break;}}}}}
	 else if(chess_board[i][j]==(-12)){
        for(k=0;k<=7;k++){
                if (t==1){break;}
                for(p=0;p<=7;p++){
                    if(pr2==0){t = pawn_moves(kill=0,i,j,k,p,chess_board);}
                    if (t==1){h=check(chess_board,i,j,k,p,kill,pr,pr2,pr3,pr4,pr5,pr6,pr7,pr8,prb,prb2,prb3,prb4,prb5,prb6,prb7,prb8);
                        if(h==1){t=0;}
                        else if(h==0){break;}}
        if(pr2==0){t=pawn_moves(kill=1,i,j,k,p,chess_board);}
        else if(pr2==1){t=queen_moves(i,j,k,p,chess_board,kill);}
        else if(pr2==2){t=rook_moves(i,j,k,p,chess_board,kill);}
        else if(pr2==3){t=bishop_moves(i,j,k,p,chess_board,kill);}
        else if(pr2==4){t=horse_moves(i,j,k,p,chess_board,kill);}
        if (t==1){h=check(chess_board,i,j,k,p,kill,pr,pr2,pr3,pr4,pr5,pr6,pr7,pr8,prb,prb2,prb3,prb4,prb5,prb6,prb7,prb8);
                        if(h==1){t=0;}
                        else if(h==0){break;}}}}}
	 else if(chess_board[i][j]==(-13)){
        for(k=0;k<=7;k++){
                if (t==1){break;}
                for(p=0;p<=7;p++){
                    if(pr3==0){t = pawn_moves(kill=0,i,j,k,p,chess_board);}
                    if (t==1){h=check(chess_board,i,j,k,p,kill,pr,pr2,pr3,pr4,pr5,pr6,pr7,pr8,prb,prb2,prb3,prb4,prb5,prb6,prb7,prb8);
                        if(h==1){t=0;}
                        else if(h==0){break;}}
        if(pr3==0){t=pawn_moves(kill=1,i,j,k,p,chess_board);}
        else if(pr3==1){t=queen_moves(i,j,k,p,chess_board,kill);}
        else if(pr3==2){t=rook_moves(i,j,k,p,chess_board,kill);}
        else if(pr3==3){t=bishop_moves(i,j,k,p,chess_board,kill);}
        else if(pr3==4){t=horse_moves(i,j,k,p,chess_board,kill);}
        if (t==1){h=check(chess_board,i,j,k,p,kill,pr,pr2,pr3,pr4,pr5,pr6,pr7,pr8,prb,prb2,prb3,prb4,prb5,prb6,prb7,prb8);
                        if(h==1){t=0;}
                        else if(h==0){break;}}}}}
	 else if(chess_board[i][j]==(-14)){
               for(k=0;k<=7;k++){
                if (t==1){break;}
                for(p=0;p<=7;p++){
                    if(pr4==0){t = pawn_moves(kill=0,i,j,k,p,chess_board);}
                    if (t==1){h=check(chess_board,i,j,k,p,kill,pr,pr2,pr3,pr4,pr5,pr6,pr7,pr8,prb,prb2,prb3,prb4,prb5,prb6,prb7,prb8);
                        if(h==1){t=0;}
                        else if(h==0){break;}}
        if(pr4==0){t=pawn_moves(kill=1,i,j,k,p,chess_board);}
        else if(pr4==1){t=queen_moves(i,j,k,p,chess_board,kill);}
        else if(pr4==2){t=rook_moves(i,j,k,p,chess_board,kill);}
        else if(pr4==3){t=bishop_moves(i,j,k,p,chess_board,kill);}
        else if(pr4==4){t=horse_moves(i,j,k,p,chess_board,kill);}
        if (t==1){h=check(chess_board,i,j,k,p,kill,pr,pr2,pr3,pr4,pr5,pr6,pr7,pr8,prb,prb2,prb3,prb4,prb5,prb6,prb7,prb8);
                        if(h==1){t=0;}
                        else if(h==0){break;}}}}}
	 else if(chess_board[i][j]==(-15)){
            for(k=0;k<=7;k++){
                if (t==1){break;}
                for(p=0;p<=7;p++){
                    if(pr5==0){t = pawn_moves(kill=0,i,j,k,p,chess_board);}
                    if (t==1){h=check(chess_board,i,j,k,p,kill,pr,pr2,pr3,pr4,pr5,pr6,pr7,pr8,prb,prb2,prb3,prb4,prb5,prb6,prb7,prb8);
                        if(h==1){t=0;}
                        else if(h==0){break;}}
        if(pr5==0){t=pawn_moves(kill=1,i,j,k,p,chess_board);}
        else if(pr5==1){t=queen_moves(i,j,k,p,chess_board,kill);}
        else if(pr5==2){t=rook_moves(i,j,k,p,chess_board,kill);}
        else if(pr5==3){t=bishop_moves(i,j,k,p,chess_board,kill);}
        else if(pr5==4){t=horse_moves(i,j,k,p,chess_board,kill);}
        if (t==1){h=check(chess_board,i,j,k,p,kill,pr,pr2,pr3,pr4,pr5,pr6,pr7,pr8,prb,prb2,prb3,prb4,prb5,prb6,prb7,prb8);
                        if(h==1){t=0;}
                        else if(h==0){break;}}}}}
	 else if(chess_board[i][j]==(-16)){
            for(k=0;k<=7;k++){
                if (t==1){break;}
                for(p=0;p<=7;p++){
                    if(pr6==0){t = pawn_moves(kill=0,i,j,k,p,chess_board);}
                    if (t==1){h=check(chess_board,i,j,k,p,kill,pr,pr2,pr3,pr4,pr5,pr6,pr7,pr8,prb,prb2,prb3,prb4,prb5,prb6,prb7,prb8);
                        if(h==1){t=0;}
                        else if(h==0){break;}}
        if(pr6==0){t=pawn_moves(kill=1,i,j,k,p,chess_board);}
        else if(pr6==1){t=queen_moves(i,j,k,p,chess_board,kill);}
        else if(pr6==2){t=rook_moves(i,j,k,p,chess_board,kill);}
        else if(pr6==3){t=bishop_moves(i,j,k,p,chess_board,kill);}
        else if(pr6==4){t=horse_moves(i,j,k,p,chess_board,kill);}
        if (t==1){h=check(chess_board,i,j,k,p,kill,pr,pr2,pr3,pr4,pr5,pr6,pr7,pr8,prb,prb2,prb3,prb4,prb5,prb6,prb7,prb8);
                        if(h==1){t=0;}
                        else if(h==0){break;}}}}}
	 else if(chess_board[i][j]==(-17)){
            for(k=0;k<=7;k++){
                if (t==1){break;}
                for(p=0;p<=7;p++){
                    if(pr7==0){t = pawn_moves(kill=0,i,j,k,p,chess_board);}
                    if (t==1){h=check(chess_board,i,j,k,p,kill,pr,pr2,pr3,pr4,pr5,pr6,pr7,pr8,prb,prb2,prb3,prb4,prb5,prb6,prb7,prb8);
                        if(h==1){t=0;}
                        else if(h==0){break;}}
        if(pr7==0){t=pawn_moves(kill=1,i,j,k,p,chess_board);}
        else if(pr7==1){t=queen_moves(i,j,k,p,chess_board,kill);}
        else if(pr7==2){t=rook_moves(i,j,k,p,chess_board,kill);}
        else if(pr7==3){t=bishop_moves(i,j,k,p,chess_board,kill);}
        else if(pr7==4){t=horse_moves(i,j,k,p,chess_board,kill);}
        if (t==1){h=check(chess_board,i,j,k,p,kill,pr,pr2,pr3,pr4,pr5,pr6,pr7,pr8,prb,prb2,prb3,prb4,prb5,prb6,prb7,prb8);
                        if(h==1){t=0;}
                        else if(h==0){break;}}}}}
	 else if(chess_board[i][j]==(-18)){
            for(k=0;k<=7;k++){
                if (t==1){break;}
                for(p=0;p<=7;p++){
                    if(pr8==0){t = pawn_moves(kill=0,i,j,k,p,chess_board);}
                    if (t==1){h=check(chess_board,i,j,k,p,kill,pr,pr2,pr3,pr4,pr5,pr6,pr7,pr8,prb,prb2,prb3,prb4,prb5,prb6,prb7,prb8);
                        if(h==1){t=0;}
                        else if(h==0){break;}}
        if(pr8==0){t=pawn_moves(kill=1,i,j,k,p,chess_board);}
        else if(pr8==1){t=queen_moves(i,j,k,p,chess_board,kill);}
        else if(pr8==2){t=rook_moves(i,j,k,p,chess_board,kill);}
        else if(pr8==3){t=bishop_moves(i,j,k,p,chess_board,kill);}
        else if(pr8==4){t=horse_moves(i,j,k,p,chess_board,kill);}
        if (t==1){h=check(chess_board,i,j,k,p,kill,pr,pr2,pr3,pr4,pr5,pr6,pr7,pr8,prb,prb2,prb3,prb4,prb5,prb6,prb7,prb8);
                        if(h==1){t=0;}
                        else if(h==0){break;}}}}}
	 else if(chess_board[i][j]==(-2) || chess_board[i][j]==(-7)){
            for(k=0;k<=7;k++){
                if (t==1){break;}
                for(p=0;p<=7;p++){t = horse_moves(i,j,k,p,chess_board,kill);
                    if (t==1){h=check(chess_board,i,j,k,p,kill,pr,pr2,pr3,pr4,pr5,pr6,pr7,pr8,prb,prb2,prb3,prb4,prb5,prb6,prb7,prb8);
                        if(h==1){t=0;}
                        else if(h==0){break;}}}}}
	 else if(chess_board[i][j]==(-5)){
            for(k=0;k<=7;k++){
                if (t==1){break;}
                for(p=0;p<=7;p++){t = queen_moves(i,j,k,p,chess_board,kill);
                    if (t==1){h=check(chess_board,i,j,k,p,kill,pr,pr2,pr3,pr4,pr5,pr6,pr7,pr8,prb,prb2,prb3,prb4,prb5,prb6,prb7,prb8);
                        if(h==1){t=0;}
                        else if(h==0){break;}}}}}
	 else if(chess_board[i][j]==(-1) || chess_board[i][j]==(-8)){
            for(k=0;k<=7;k++){if (t==1){break;}
                for(p=0;p<=7;p++){t = rook_moves(i,j,k,p,chess_board,kill);
                    if (t==1){h=check(chess_board,i,j,k,p,kill,pr,pr2,pr3,pr4,pr5,pr6,pr7,pr8,prb,prb2,prb3,prb4,prb5,prb6,prb7,prb8);
                        if(h==1){t=0;}
                        else if(h==0){break;}}}}}
	 else if(chess_board[i][j]==(-3) || chess_board[i][j]==(-6)){
            for(k=0;k<=7;k++){
                if (t==1){break;}
                for(p=0;p<=7;p++){t = bishop_moves(i,j,k,p,chess_board,kill);
                    if (t==1){h=check(chess_board,i,j,k,p,kill,pr,pr2,pr3,pr4,pr5,pr6,pr7,pr8,prb,prb2,prb3,prb4,prb5,prb6,prb7,prb8);
                        if(h==1){t=0;}
                        else if(h==0){break;}}}}}
	 else if(chess_board[i][j]==(-4)){
      for(k=0;k<=7;k++){if (t==1){break;}
                for(p=0;p<=7;p++){t=0;
                    if(((k==i && p==j+1)||(k==i && p==j-1)||(k==i+1 && p==j)||(k==i+1 && p==j+1)||(k==i+1 && p==j-1)||(k==i-1 && p==j)||(k==i-1 && p==j+1)||(k==i-1 && p==j-1))&&((p<8)&&(k<8))){t=1;}
                    if((chess_board[i][j]<0) && (chess_board[k][p]<0)){t=0;}
                    else if(chess_board[i][j]>0 && chess_board[k][p]>0){t=0;}
                    if (t==1){h=check(chess_board,i,j,k,p,kill,pr,pr2,pr3,pr4,pr5,pr6,pr7,pr8,prb,prb2,prb3,prb4,prb5,prb6,prb7,prb8);
                        if(h==1){t=0;}
                        else if(h==0){break;}}}}}
    if (t==1){break;}}}}
return t;}

